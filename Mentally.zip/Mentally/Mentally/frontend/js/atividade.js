// ---------- LocalStorage Usuario ----------
document.addEventListener("DOMContentLoaded", () => {
  const usuario = JSON.parse(localStorage.getItem("usuario"));
  if (usuario && usuario.nome) {
    document.getElementById("nome-usuario").textContent = usuario.nome;
  }
});

const btnMobile = document.getElementById('btn-mobile');
const nav = document.getElementById('nav');
const menu = document.getElementById('menu');
const desktopSocial = document.getElementById('navigation_social');
const desktopIcons = document.getElementById('icons');
const desktopTitle = document.getElementById('title');
const hamburger = document.getElementById('hamburger');

btnMobile.addEventListener('click', toggleMenu);
btnMobile.addEventListener('touchstart', toggleMenu);

function toggleMenu(event) {
  if (event.type === 'touchstart') event.preventDefault();

  nav.classList.toggle('active');
  hamburger.classList.toggle('active');

  const active = nav.classList.contains('active');
  event.currentTarget.setAttribute('aria-expanded', active);
  event.currentTarget.setAttribute('aria-label', active ? 'Fechar Menu' : 'Abrir Menu');

  // Quando abrir o menu mobile
  if (active && window.innerWidth <= 1100) {
    // Adiciona o título
    if (!document.getElementById('mobile-title')) {
      const mobileTitle = desktopTitle.cloneNode(true);
      mobileTitle.id = 'mobile-title';
      menu.prepend(mobileTitle);
    }

    
    // Adiciona os ícones sociais
    if (!document.getElementById('mobile-social')) {
      const mobileSocial = desktopSocial.cloneNode(true);
      mobileSocial.id = 'mobile-social';
      menu.appendChild(mobileSocial);
    }
    
    // Adiciona os ícones
    if (!document.getElementById('mobile-icons')) {
      const mobileIcons = desktopIcons.cloneNode(true);
      mobileIcons.id = 'mobile-icons';
      menu.appendChild(mobileIcons);
    }
  }

  // Quando fechar o menu mobile
  if (!active) {
    const mobileTitle = document.getElementById('mobile-title');
    const mobileSocial = document.getElementById('mobile-social');
    const mobileIcons = document.getElementById('mobile-icons');

    if (mobileTitle) mobileTitle.remove();
    if (mobileSocial) mobileSocial.remove();
    if (mobileIcons) mobileIcons.remove();
  }
}


// ---------- Dark Mode ----------
const chk = document.getElementById('checkbox');
const logo = document.getElementById('logo');

// Verifica se já tem preferência salva e aplica
if(localStorage.getItem('modo') === 'dark'){
  document.body.classList.add('dark');
  chk.checked = true;
  logo.src = "/img/mentaally colorido.png"; // versão clara
} else {
  logo.src = "/img/mentaally.png"; // versão escuraa
}

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  
  if(document.body.classList.contains('dark')){
    localStorage.setItem('modo', 'dark');
    logo.src = "/img/mentaally colorido.png"; // troca p/ dark

  } else {
    localStorage.setItem('modo', 'light');
    logo.src = "/img/mentaally.png"; // volta p/ light
  
  }
});
// ===============================
// SISTEMA DE MODAIS (GENÉRICO)
// ===============================

// Abrir modal
document.querySelectorAll("[data-target]").forEach(btn => {
  btn.addEventListener("click", () => {
    const modalId = btn.getAttribute("data-target");
    document.getElementById(modalId).style.display = "block";
  });
});

// Fechar modal (X)
document.querySelectorAll(".modal .close").forEach(closeBtn => {
  closeBtn.addEventListener("click", () => {
    closeBtn.closest(".modal").style.display = "none";
  });
});

// Fechar clicando fora
window.addEventListener("click", e => {
  if (e.target.classList.contains("modal")) {
    e.target.style.display = "none";
  }
});


// ===============================
// GUIA DE RESPIRAÇÃO (modal-respiracao) REFACTOR
// ===============================
const circle = document.getElementById("circle");
const statusEl = document.getElementById("status");
const instructionEl = document.getElementById("instruction");
const progressBar = document.getElementById("progress");
const tempoSelect = document.getElementById("tempo");
const startPauseBtn = document.getElementById("startPauseBtn");

let ciclo = ["Inspire", "Segure", "Expire"];
let tempos = [4, 7, 8]; // duração de cada fase
let faseAtual = 0;
let contador = 0;
let totalTime = 0;
let elapsed = 0;
let faseTimer = null;
let isRunning = false;
let isPaused = false;

// Alternar iniciar / pausar / retomar
function toggleExercicio() {
  if (!isRunning) {
    iniciar();
  } else if (!isPaused) {
    pausar();
  } else {
    retomar();
  }
}

// Iniciar exercício
function iniciar() {
  reiniciar(); // resetar tudo antes

  totalTime = parseInt(tempoSelect.value);
  elapsed = 0;
  faseAtual = 0;
  contador = tempos[faseAtual];
  isRunning = true;
  isPaused = false;

  circle.style.animation = "none"; // remove qualquer conflito CSS
  atualizarFase();

  faseTimer = setInterval(() => {
    if (!isPaused) {
      contador--;
      elapsed++;
      progressBar.style.width = `${(elapsed / totalTime) * 100}%`;
      statusEl.textContent = `${ciclo[faseAtual]} por ${contador}s`;

      if (contador <= 0) {
        faseAtual = (faseAtual + 1) % ciclo.length;
        if (elapsed < totalTime) {
          contador = tempos[faseAtual];
          atualizarFase();
        } else {
          finalizar();
        }
      }
    }
  }, 1000);

  startPauseBtn.textContent = "Pausar";
}

// Pausar
function pausar() {
  isPaused = true;
  startPauseBtn.textContent = "Retomar";
}

// Retomar
function retomar() {
  isPaused = false;
  startPauseBtn.textContent = "Pausar";
  
}

// Reiniciar
function reiniciar() {
  clearInterval(faseTimer);
  faseTimer = null;
  elapsed = 0;
  faseAtual = 0;
  contador = tempos[0];
  progressBar.style.width = "0%";
  statusEl.textContent = "Aguardando início...";
  circle.textContent = "Prepare-se";
  circle.style.transform = "scale(1)";
  circle.style.background = "linear-gradient(135deg, #6a5acd, #8a2be2)";
  startPauseBtn.textContent = "Iniciar";
  isRunning = false;
  isPaused = false;
}

// Finalizar
function finalizar() {
  clearInterval(faseTimer);
  faseTimer = null;
  circle.textContent = "Fim";
  statusEl.textContent = "Concluído ✅";
  circle.style.transform = "scale(1)";
  circle.style.background = "linear-gradient(135deg, #6a5acd, #8a2be2)";
  startPauseBtn.textContent = "Iniciar";
  isRunning = false;
  isPaused = false;
}

// Atualizar círculo e estilo de cada fase
function atualizarFase() {
  let fase = ciclo[faseAtual];
  circle.textContent = fase;

  if (fase === "Inspire") {
    circle.style.transform = "scale(1.2)";
    circle.style.background = "linear-gradient(135deg, #984cefff, #2196f3)";
  } else if (fase === "Segure") {
    circle.style.transform = "scale(1.3)";
    circle.style.background = "linear-gradient(135deg, #ffc107, #ff9800)";
  } else {
    circle.style.transform = "scale(1)";
    circle.style.background = "linear-gradient(135deg, #f44336, #e91e63)";
  }
}


function etapaRetomada() {
  let fase = ciclo[i];
  circle.textContent = fase; // mostra a fase no círculo
  atualizarEstilo(fase);
  statusEl.textContent = `${fase} por ${contador}s`;

  faseTimer = setInterval(() => {
    if (!isPaused) {
      contador--;
      elapsed++;
      progressBar.style.width = `${(elapsed / totalTime) * 100}%`;
      statusEl.textContent = `${fase} por ${contador}s`;

      if (contador <= 0) {
        clearInterval(faseTimer);
        i = (i + 1) % ciclo.length;
        if (elapsed < totalTime) {
          etapaRetomada();
        } else {
          finalizar();
        }
      }
    }
  }, 1000);
}




// ===============================
// TIMER DE MEDITAÇÃO (modal-meditacao)
// ===============================
const timerDisplay = document.getElementById("timer");
const duracaoSelect = document.getElementById("duracao");
const startMeditacao = document.querySelector("#modal-meditacao #startPauseBtn");

let medTimer;
let medSegundos;
let isMedRunning = false;
let isMedPaused = false;

function atualizarTimer() {
  let min = String(Math.floor(medSegundos / 60)).padStart(2, "0");
  let sec = String(medSegundos % 60).padStart(2, "0");
  timerDisplay.textContent = `${min}:${sec}`;
}

function iniciarMeditacao() {
  medSegundos = parseInt(duracaoSelect.value);
  atualizarTimer();

  medTimer = setInterval(() => {
    if (!isMedPaused) {
      medSegundos--;
      atualizarTimer();

      if (medSegundos <= 0) {
        finalizarMeditacao();
      }
    }
  }, 1000);
}

function pausarMeditacao() {
  isMedPaused = true;
  startMeditacao.textContent = "Retomar";
}

function retomarMeditacao() {
  isMedPaused = false;
  startMeditacao.textContent = "Pausar";
}

function finalizarMeditacao() {
  clearInterval(medTimer);
  timerDisplay.textContent = "Concluído ✅";
  startMeditacao.textContent = "Iniciar";
  isMedRunning = false;
  isMedPaused = false;
}

// Alternar entre iniciar, pausar e retomar
startMeditacao.addEventListener("click", () => {
  if (!isMedRunning) {
    iniciarMeditacao();
    startMeditacao.textContent = "Pausar";
    isMedRunning = true;
  } else if (!isMedPaused) {
    pausarMeditacao();
  } else {
    retomarMeditacao();
  }
});

// Atualiza timer inicial
medSegundos = parseInt(duracaoSelect.value);
atualizarTimer();
