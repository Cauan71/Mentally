document.addEventListener("DOMContentLoaded", () => {
  const usuario = JSON.parse(localStorage.getItem("usuario"));
  if (usuario && usuario.nome) {
    document.querySelectorAll(".nome-usuario").forEach(el => {
      el.textContent = usuario.nome;
    });
  }
});


//modo escuro- modo claro
const chk = document.getElementById('checkbox');
const logo = document.querySelectorAll('.logo'); // agora pega o <img>

// Verifica se já tem preferência salva e aplica
if(localStorage.getItem('modo') === 'dark'){
  document.body.classList.add('dark');
  chk.checked = true;
  logo.src = "img/mentaally-colorido.png"; // versão clara
} else {
  logo.src = "img/mentaally.png"; // versão escuraa
}

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  
  if(document.body.classList.contains('dark')){
    localStorage.setItem('modo', 'dark');
    logo.src = "img/mentaally-colorido.png"; // troca p/ dark

  } else {
    localStorage.setItem('modo', 'light');
    logo.src = "img/mentaally.png"; // volta p/ light
  
  }
});

const btnMobile = document.getElementById('btn-mobile');
const nav = document.getElementById('nav');
const menu = document.getElementById('menu');
const desktopSocial = document.getElementById('navigation_social');
const desktopIcons = document.getElementById('icons');
const desktopTitle = document.getElementById('title');
const hamburger = document.getElementById('hamburger');

btnMobile.addEventListener('click', toggleMenu);
btnMobile.addEventListener('touchstart', toggleMenu);

function toggleMenu(event) {
  if (event.type === 'touchstart') event.preventDefault();

  nav.classList.toggle('active');
  hamburger.classList.toggle('active');

  const active = nav.classList.contains('active');
  event.currentTarget.setAttribute('aria-expanded', active);
  event.currentTarget.setAttribute('aria-label', active ? 'Fechar Menu' : 'Abrir Menu');

  // Quando abrir o menu mobile
  if (active && window.innerWidth <= 1100) {
    // Adiciona o título
    if (!document.getElementById('mobile-title')) {
      const mobileTitle = desktopTitle.cloneNode(true);
      mobileTitle.id = 'mobile-title';
      menu.prepend(mobileTitle);
    }

    
    // Adiciona os ícones sociais
    if (!document.getElementById('mobile-social')) {
      const mobileSocial = desktopSocial.cloneNode(true);
      mobileSocial.id = 'mobile-social';
      menu.appendChild(mobileSocial);
    }
    
    // Adiciona os ícones
    if (!document.getElementById('mobile-icons')) {
      const mobileIcons = desktopIcons.cloneNode(true);
      mobileIcons.id = 'mobile-icons';
      menu.appendChild(mobileIcons);
    }
  }

  // Quando fechar o menu mobile
  if (!active) {
    const mobileTitle = document.getElementById('mobile-title');
    const mobileSocial = document.getElementById('mobile-social');
    const mobileIcons = document.getElementById('mobile-icons');

    if (mobileTitle) mobileTitle.remove();
    if (mobileSocial) mobileSocial.remove();
    if (mobileIcons) mobileIcons.remove();
  }
}


 // ===== Seletores =====
    const moods = document.querySelectorAll('.mood');
    const btn = document.querySelector('.btn');
    const daysContainer = document.querySelector('.days');
    const messageEl = document.getElementById('message');

    let selectedMood = null;

    // Carrega histórico do localStorage ou inicializa vazio
    let history = JSON.parse(localStorage.getItem('moodHistory')) || [];

    // ===== Função para renderizar histórico =====
    function renderHistory() {
      daysContainer.innerHTML = '';
      for (let i = 0; i < 7; i++) {
        const mood = history[i] || { emoji: '?', color: 'gray' };
        const div = document.createElement('div');
        div.className = `day ${mood.color}`;
        div.textContent = mood.emoji;
        daysContainer.appendChild(div);
      }
    }

    // ===== Função para mostrar mensagem animada =====
    function showMessage(text, type = 'success', duration = 3000) {
      messageEl.textContent = text;
      messageEl.className = `message show ${type}`;

      // Esconde após o tempo definido
      setTimeout(() => {
        messageEl.className = `message hide ${type}`;
      }, duration);
    }

    // ===== Seleção de humor =====
    moods.forEach(mood => {
      mood.addEventListener('click', () => {
        moods.forEach(m => m.classList.remove('selected')); // Remove seleção anterior
        mood.classList.add('selected'); // Marca o selecionado
        selectedMood = {
          emoji: mood.querySelector('span').textContent,
          color: mood.dataset.color
        };
        btn.disabled = false; // Habilita o botão
      });
    });

  // ===== Registrar humor =====
  btn.addEventListener('click', () => {
    if (!selectedMood) {
      showMessage("Você precisa escolher um humor!", "warning");
      return;
    }

    const today = new Date().toLocaleDateString();
    const lastEntry = history[0] ? history[0].date : null;

    // Evita múltiplos registros no mesmo dia
    if (lastEntry === today) {
      showMessage("Você já registrou seu humor hoje!", "error");
      return;
    }

    // Adiciona humor com data
    history.unshift({ ...selectedMood, date: today });
    if (history.length > 7) history.pop(); // Mantém apenas 7 dias
    localStorage.setItem('moodHistory', JSON.stringify(history));
    renderHistory();

    // Reset seleção
    selectedMood = null;
    moods.forEach(m => m.classList.remove('selected'));
    btn.disabled = true;

    // Mostra mensagem de sucesso
    showMessage("Humor registrado com sucesso!", "success");
  });

  // Renderiza histórico ao carregar página
  renderHistory();



 // Daily Insights
        const dailyInsights = [
            "A prática da gratidão por apenas 5 minutos diários pode aumentar significativamente seu bem-estar emocional.",
            "Pequenas pausas durante o trabalho melhoram a concentração e reduzem o estresse acumulado.",
            "A respiração consciente ativa o sistema nervoso parassimpático, promovendo relaxamento natural.",
            "Estabelecer limites saudáveis é um ato de autocuidado, não de egoísmo.",
            "O exercício físico regular é tão eficaz quanto alguns medicamentos no tratamento da depressão leve.",
            "Dormir bem não é luxo, é necessidade básica para a saúde mental e física.",
            "Conectar-se com a natureza, mesmo por poucos minutos, reduz cortisol e melhora o humor.",
            "A meditação mindfulness pode literalmente mudar a estrutura do seu cérebro de forma positiva.",
            "Expressar emoções de forma saudável fortalece relacionamentos e reduz tensão interna.",
            "Aprender algo novo estimula a neuroplasticidade e aumenta a sensação de propósito."
        ];

        // Header scroll effect
        function handleHeaderScroll() {
            const header = document.getElementById('header');
            if (window.scrollY > 100) {
                header.classList.add('header-scrolled');
            } else {
                header.classList.remove('header-scrolled');
            }
        }

        // Daily insight display
        function showDailyInsight() {
            const today = new Date();
            const dayOfYear = Math.floor((today - new Date(today.getFullYear(), 0, 0)) / 1000 / 60 / 60 / 24);
            const insightIndex = dayOfYear % dailyInsights.length;
            
            document.getElementById('daily-insight').textContent = dailyInsights[insightIndex];
        }

        // Breathing exercise
        function initBreathingExercise() {
            const circle = document.getElementById('breathing-circle');
            const text = document.getElementById('breathing-text');
            let isActive = false;
            let currentPhase = 0; // 0: inhale, 1: hold, 2: exhale
            let timer;

            const phases = [
                { text: 'Inspire', duration: 4000 },
                { text: 'Segure', duration: 7000 },
                { text: 'Expire', duration: 8000 }
            ];

            circle.addEventListener('click', function() {
                if (!isActive) {
                    startBreathing();
                } else {
                    stopBreathing();
                }
            });

            function startBreathing() {
                isActive = true;
                circle.classList.add('active');
                runPhase();
            }

            function stopBreathing() {
                isActive = false;
                circle.classList.remove('active');
                text.textContent = 'Iniciar';
                clearTimeout(timer);
                currentPhase = 0;
            }

            function runPhase() {
                if (!isActive) return;

                const phase = phases[currentPhase];
                text.textContent = phase.text;

                timer = setTimeout(() => {
                    currentPhase = (currentPhase + 1) % phases.length;
                    if (currentPhase === 0 && isActive) {
                        // Completed one full cycle, continue
                        runPhase();
                    } else if (isActive) {
                        runPhase();
                    }
                }, phase.duration);
            }
        }

        // Testimonials slider
        function initTestimonialsSlider() {
            const track = document.getElementById('testimonials-track');
            const dots = document.querySelectorAll('.nav-dot');
            let currentSlide = 0;
            const totalSlides = dots.length;

            function goToSlide(slideIndex) {
                currentSlide = slideIndex;
                track.style.transform = `translateX(-${currentSlide * 100}%)`;
                
                dots.forEach((dot, index) => {
                    dot.classList.toggle('active', index === currentSlide);
                });
            }

            // Add click listeners to dots
            dots.forEach((dot, index) => {
                dot.addEventListener('click', () => goToSlide(index));
            });

            // Auto-advance slides
            setInterval(() => {
                const nextSlide = (currentSlide + 1) % totalSlides;
                goToSlide(nextSlide);
            }, 6000);
        }

        // Smooth scrolling for navigation links
        function initSmoothScrolling() {
            const links = document.querySelectorAll('a[href^="#"]');
            
            links.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    const targetId = this.getAttribute('href');
                    const targetSection = document.querySelector(targetId);
                    
                    if (targetSection) {
                        const headerHeight = document.getElementById('header').offsetHeight;
                        const targetPosition = targetSection.offsetTop - headerHeight;
                        
                        window.scrollTo({
                            top: targetPosition,
                            behavior: 'smooth'
                        });
                    }
                });
            });
        }

        // Intersection Observer for animations
        function initScrollAnimations() {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.style.opacity = '1';
                        entry.target.style.transform = 'translateY(0)';
                    }
                });
            }, {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            });

            // Observe elements for animation
            const elementsToAnimate = document.querySelectorAll('.service-card, .blog-card, .hero-card');
            elementsToAnimate.forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(30px)';
                el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(el);
            });
        }

        // Modal functionality
        function openModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.classList.add('show');
                document.body.style.overflow = 'hidden'; // Prevent background scrolling
            }
        }

        function closeModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.classList.remove('show');
                document.body.style.overflow = 'auto'; // Restore scrolling
            }
        }

        // Close modal when clicking outside content
        function initModalCloseOnOutsideClick() {
            const modals = document.querySelectorAll('.modal');
            modals.forEach(modal => {
                modal.addEventListener('click', function(e) {
                    if (e.target === modal) {
                        const modalId = modal.getAttribute('id');
                        closeModal(modalId);
                    }
                });
            });
        }

        // Close modal with Escape key
        function initModalEscapeKey() {
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    const openModal = document.querySelector('.modal.show');
                    if (openModal) {
                        const modalId = openModal.getAttribute('id');
                        closeModal(modalId);
                    }
                }
            });
        }

        // Initialize all functionality
        document.addEventListener('DOMContentLoaded', function() {
            showDailyInsight();
            initBreathingExercise();
            initTestimonialsSlider();
            initSmoothScrolling();
            initScrollAnimations();
            initModalCloseOnOutsideClick();
            initModalEscapeKey();
            
            // Add scroll listener for header
            window.addEventListener('scroll', handleHeaderScroll);
        });

        // Update insight daily
        setInterval(showDailyInsight, 24 * 60 * 60 * 1000);
    
(function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.__CF$cv$params={r:'97c65cd757a4f632',t:'MTc1NzQxNzUyMi4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";b.getElementsByTagName('head')[0].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();


// 
 const mensagens = [
    "você não precisa ter todas as respostas hoje. Um passo já é progresso.",
    "pequenas conquistas levam a grandes resultados, não se apresse.",
    "a cada dia é uma nova oportunidade de aprender e crescer.",
    "respeite seu tempo e celebre suas vitórias, mesmo as pequenas.",
    "confie no processo, o que é seu vai chegar na hora certa.",
    "a gratidão transforma o que temos em suficiente e nos faz felizes.",
    "sua jornada é única, compare apenas consigo mesmo."
  ];

  const mensagemEl = document.querySelector(".mensagem");

  // Seleciona uma mensagem diferente a cada dia
  function getMensagemDoDia() {
    const hoje = new Date();
    const index = hoje.getDate() % mensagens.length;
    return mensagens[index];
  }

  mensagemEl.innerText = getMensagemDoDia();

  // Função para compartilhar
  document.getElementById("shareBtn").addEventListener("click", () => {
    const text = mensagemEl.innerText;
    if (navigator.share) {
      navigator.share({ text }).catch(console.error);
    } else {
      alert("Copiado para a área de transferência:\n" + text);
      navigator.clipboard.writeText(text);
    }
  });

  // Função para salvar
  document.getElementById("saveBtn").addEventListener("click", () => {
    const text = mensagemEl.innerText;
    const blob = new Blob([text], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "reflexao.txt";
    a.click();
  });



