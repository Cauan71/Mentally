// ======== LocalStorage do Usuário ========
document.addEventListener("DOMContentLoaded", () => {
  const usuario = JSON.parse(localStorage.getItem("usuario"));
  if (usuario && usuario.nome) {
    document.getElementById("nome-usuario").textContent = usuario.nome;
  }
});

// ======== Menu Mobile ========
const btnMobile = document.getElementById('btn-mobile');
const nav = document.getElementById('nav');
const menu = document.getElementById('menu');
const desktopSocial = document.getElementById('navigation_social');
const desktopIcons = document.getElementById('icons');
const desktopTitle = document.getElementById('title');
const hamburger = document.getElementById('hamburger');

btnMobile.addEventListener('click', toggleMenu);
btnMobile.addEventListener('touchstart', toggleMenu);

function toggleMenu(event) {
  if (event.type === 'touchstart') event.preventDefault();
  nav.classList.toggle('active');
  hamburger.classList.toggle('active');

  const active = nav.classList.contains('active');
  event.currentTarget.setAttribute('aria-expanded', active);
  event.currentTarget.setAttribute('aria-label', active ? 'Fechar Menu' : 'Abrir Menu');

  if (active && window.innerWidth <= 1100) {
    if (!document.getElementById('mobile-title')) {
      const mobileTitle = desktopTitle.cloneNode(true);
      mobileTitle.id = 'mobile-title';
      menu.prepend(mobileTitle);
    }
    if (!document.getElementById('mobile-social')) {
      const mobileSocial = desktopSocial.cloneNode(true);
      mobileSocial.id = 'mobile-social';
      menu.appendChild(mobileSocial);
    }
    if (!document.getElementById('mobile-icons')) {
      const mobileIcons = desktopIcons.cloneNode(true);
      mobileIcons.id = 'mobile-icons';
      menu.appendChild(mobileIcons);
    }
  } else if (!active) {
    const mobileTitle = document.getElementById('mobile-title');
    const mobileSocial = document.getElementById('mobile-social');
    const mobileIcons = document.getElementById('mobile-icons');
    if (mobileTitle) mobileTitle.remove();
    if (mobileSocial) mobileSocial.remove();
    if (mobileIcons) mobileIcons.remove();
  }
}

// ======== Modo escuro/claro ========
const chk = document.getElementById('checkbox');
const logo = document.getElementById('logo');

if(localStorage.getItem('modo') === 'dark'){
  document.body.classList.add('dark');
  chk.checked = true;
  logo.src = "/img/mentaally colorido.png";
} else {
  logo.src = "/img/mentaally.png";
}

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  if(document.body.classList.contains('dark')){
    localStorage.setItem('modo', 'dark');
    logo.src = "/img/mentaally colorido.png";
  } else {
    localStorage.setItem('modo', 'light');
    logo.src = "/img/mentaally.png";
  }
});

// ======== Alternar abas ========
function showTab(tab) {
  document.querySelectorAll(".tab-content").forEach(div => div.style.display = "none");
  document.getElementById(tab).style.display = "block";

  document.querySelectorAll(".tab-btn").forEach(btn => btn.classList.remove("active"));
  document.querySelector(`.tab-btn[onclick="showTab('${tab}')"]`).classList.add("active");
}

// ======== Buscar agendamentos ========
document.addEventListener("DOMContentLoaded", () => {
  const usuario = JSON.parse(localStorage.getItem("usuario"));
  if (!usuario) return;

  const proximasDiv = document.getElementById("proximas");
  proximasDiv.innerHTML = "";

  fetch(`http://localhost:3001/agendamentos/${usuario.id_usuario}`)
    .then(res => res.json())
    .then(agendamentos => {
      agendamentos.forEach(a => {
        const dataFormatada = new Date(a.data_consulta).toLocaleDateString("pt-BR", { weekday:"long", year:"numeric", month:"long", day:"numeric" });

        const card = document.createElement("div");
        card.classList.add("consulta");
        card.innerHTML = `
          <div class="consulta-left">
            <img src="img/premium_photo-1689568126014-06fea9d5d341.jpg" alt="Dr">
            <div>
              <span class="status">Agendado</span>
              <h3>${a.nome_profissional}</h3>
              <p>${a.especialidade}</p>
            </div>
          </div>
          <div class="consulta-right">
            <p><b>Data:</b> ${dataFormatada}</p>
            <p><b>Hora:</b> ${a.hora_consulta}</p>
            <p><b>Tipo:</b> Consulta Online</p>
            <div class="consulta-buttons">
              <button class="btn-green">Entrar na Consulta</button>
              <button class="btn-blue">Mensagem</button>
              <button class="btn-blue">Ver Detalhes</button>
              <button class="btn-red btn-cancelar" data-id="${a.id_consulta}">Cancelar</button>
            </div>
          </div>
        `;
        proximasDiv.appendChild(card);
      });
    })
    .catch(err => console.error("Erro ao carregar agendamentos:", err));
});

// ======== Cancelar consulta ========
document.addEventListener("click", (e) => {
  if (e.target.classList.contains("btn-cancelar")) {
    const btn = e.target;
    const idConsulta = btn.getAttribute("data-id");

    if (confirm("Deseja realmente cancelar esta consulta?")) {
      fetch(`http://localhost:3001/agendamentos/${idConsulta}`, {
        method: "DELETE"
      })
      .then(res => res.json())
      .then(data => {
        alert(data.message);
        btn.closest(".consulta").remove();
      })
      .catch(err => {
        console.error("Erro ao cancelar consulta:", err);
        alert("Não foi possível cancelar a consulta.");
      });
    }
  }
});
