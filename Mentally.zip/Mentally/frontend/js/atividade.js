// ---------- LocalStorage Usuario ----------
document.addEventListener("DOMContentLoaded", () => {
  const usuario = JSON.parse(localStorage.getItem("usuario"));
  if (usuario && usuario.nome) {
    document.getElementById("nome-usuario").textContent = usuario.nome;
  }
});

const btnMobile = document.getElementById('btn-mobile');
const nav = document.getElementById('nav');
const menu = document.getElementById('menu');
const desktopSocial = document.getElementById('navigation_social');
const desktopIcons = document.getElementById('icons');
const desktopTitle = document.getElementById('title');
const hamburger = document.getElementById('hamburger');

btnMobile.addEventListener('click', toggleMenu);
btnMobile.addEventListener('touchstart', toggleMenu);

function toggleMenu(event) {
  if (event.type === 'touchstart') event.preventDefault();

  nav.classList.toggle('active');
  hamburger.classList.toggle('active');

  const active = nav.classList.contains('active');
  event.currentTarget.setAttribute('aria-expanded', active);
  event.currentTarget.setAttribute('aria-label', active ? 'Fechar Menu' : 'Abrir Menu');

  // Quando abrir o menu mobile
  if (active && window.innerWidth <= 1100) {
    // Adiciona o título
    if (!document.getElementById('mobile-title')) {
      const mobileTitle = desktopTitle.cloneNode(true);
      mobileTitle.id = 'mobile-title';
      menu.prepend(mobileTitle);
    }

    
    // Adiciona os ícones sociais
    if (!document.getElementById('mobile-social')) {
      const mobileSocial = desktopSocial.cloneNode(true);
      mobileSocial.id = 'mobile-social';
      menu.appendChild(mobileSocial);
    }
    
    // Adiciona os ícones
    if (!document.getElementById('mobile-icons')) {
      const mobileIcons = desktopIcons.cloneNode(true);
      mobileIcons.id = 'mobile-icons';
      menu.appendChild(mobileIcons);
    }
  }

  // Quando fechar o menu mobile
  if (!active) {
    const mobileTitle = document.getElementById('mobile-title');
    const mobileSocial = document.getElementById('mobile-social');
    const mobileIcons = document.getElementById('mobile-icons');

    if (mobileTitle) mobileTitle.remove();
    if (mobileSocial) mobileSocial.remove();
    if (mobileIcons) mobileIcons.remove();
  }
}


// ---------- Dark Mode ----------
const chk = document.getElementById('checkbox');
const logo = document.getElementById('logo');

// Verifica se já tem preferência salva e aplica
if(localStorage.getItem('modo') === 'dark'){
  document.body.classList.add('dark');
  chk.checked = true;
  logo.src = "/img/mentaally colorido.png"; // versão clara
} else {
  logo.src = "/img/mentaally.png"; // versão escuraa
}

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  
  if(document.body.classList.contains('dark')){
    localStorage.setItem('modo', 'dark');
    logo.src = "/img/mentaally colorido.png"; // troca p/ dark

  } else {
    localStorage.setItem('modo', 'light');
    logo.src = "/img/mentaally.png"; // volta p/ light
  
  }
});
// ===============================
// SISTEMA DE MODAIS (GENÉRICO)
// ===============================

// Abrir modal
document.querySelectorAll("[data-target]").forEach(btn => {
  btn.addEventListener("click", () => {
    const modalId = btn.getAttribute("data-target");
    document.getElementById(modalId).style.display = "block";
  });
});

// Fechar modal (X)
document.querySelectorAll(".modal .close").forEach(closeBtn => {
  closeBtn.addEventListener("click", () => {
    closeBtn.closest(".modal").style.display = "none";
  });
});

// Fechar clicando fora
window.addEventListener("click", e => {
  if (e.target.classList.contains("modal")) {
    e.target.style.display = "none";
  }
});


// ===============================
// GUIA DE RESPIRAÇÃO (modal-respiracao) REFACTOR
// ===============================
const circle = document.getElementById("circle");
const statusEl = document.getElementById("status");
const instructionEl = document.getElementById("instruction");
const progressBar = document.getElementById("progress");
const tempoSelect = document.getElementById("tempo");
const startPauseBtn = document.getElementById("startPauseBtn");

let ciclo = ["Inspire", "Segure", "Expire"];
let tempos = [4, 7, 8]; // duração de cada fase
let faseAtual = 0;
let contador = 0;
let totalTime = 0;
let elapsed = 0;
let faseTimer = null;
let isRunning = false;
let isPaused = false;

// Alternar iniciar / pausar / retomar
function toggleExercicio() {
  if (!isRunning) {
    iniciar();
  } else if (!isPaused) {
    pausar();
  } else {
    retomar();
  }
}

// Iniciar exercício
function iniciar() {
  reiniciar(); // resetar tudo antes

  totalTime = parseInt(tempoSelect.value);
  elapsed = 0;
  faseAtual = 0;
  contador = tempos[faseAtual];
  isRunning = true;
  isPaused = false;

  circle.style.animation = "none"; // remove qualquer conflito CSS
  atualizarFase();

  faseTimer = setInterval(() => {
    if (!isPaused) {
      contador--;
      elapsed++;
      progressBar.style.width = `${(elapsed / totalTime) * 100}%`;
      statusEl.textContent = `${ciclo[faseAtual]} por ${contador}s`;

      if (contador <= 0) {
        faseAtual = (faseAtual + 1) % ciclo.length;
        if (elapsed < totalTime) {
          contador = tempos[faseAtual];
          atualizarFase();
        } else {
          finalizar();
        }
      }
    }
  }, 1000);

  startPauseBtn.textContent = "Pausar";
}

// Pausar
function pausar() {
  isPaused = true;
  startPauseBtn.textContent = "Retomar";
}

// Retomar
function retomar() {
  isPaused = false;
  startPauseBtn.textContent = "Pausar";
  
}

// Reiniciar
function reiniciar() {
  clearInterval(faseTimer);
  faseTimer = null;
  elapsed = 0;
  faseAtual = 0;
  contador = tempos[0];
  progressBar.style.width = "0%";
  statusEl.textContent = "Aguardando início...";
  circle.textContent = "Prepare-se";
  circle.style.transform = "scale(1)";
  circle.style.background = "linear-gradient(135deg, #6a5acd, #8a2be2)";
  startPauseBtn.textContent = "Iniciar";
  isRunning = false;
  isPaused = false;
}

// Finalizar
function finalizar() {
  clearInterval(faseTimer);
  faseTimer = null;
  circle.textContent = "Fim";
  statusEl.textContent = "Concluído ✅";
  circle.style.transform = "scale(1)";
  circle.style.background = "linear-gradient(135deg, #6a5acd, #8a2be2)";
  startPauseBtn.textContent = "Iniciar";
  isRunning = false;
  isPaused = false;
}

// Atualizar círculo e estilo de cada fase
function atualizarFase() {
  let fase = ciclo[faseAtual];
  circle.textContent = fase;

  if (fase === "Inspire") {
    circle.style.transform = "scale(1.2)";
    circle.style.background = "linear-gradient(135deg, #984cefff, #2196f3)";
  } else if (fase === "Segure") {
    circle.style.transform = "scale(1.3)";
    circle.style.background = "linear-gradient(135deg, #ffc107, #ff9800)";
  } else {
    circle.style.transform = "scale(1)";
    circle.style.background = "linear-gradient(135deg, #f44336, #e91e63)";
  }
}


function etapaRetomada() {
  let fase = ciclo[i];
  circle.textContent = fase; // mostra a fase no círculo
  atualizarEstilo(fase);
  statusEl.textContent = `${fase} por ${contador}s`;

  faseTimer = setInterval(() => {
    if (!isPaused) {
      contador--;
      elapsed++;
      progressBar.style.width = `${(elapsed / totalTime) * 100}%`;
      statusEl.textContent = `${fase} por ${contador}s`;

      if (contador <= 0) {
        clearInterval(faseTimer);
        i = (i + 1) % ciclo.length;
        if (elapsed < totalTime) {
          etapaRetomada();
        } else {
          finalizar();
        }
      }
    }
  }, 1000);
}

document.addEventListener("DOMContentLoaded", () => {
  // --- Elementos do DOM (Seleção pelos IDs corretos do HTML) ---
  const modal = document.getElementById("modal-meditacao");
  const displayTempo = document.getElementById("meditacao-timer");
  const selectDuracao = document.getElementById("meditacao-duracao");
  const selectTipo = document.getElementById("meditacao-tipo");
  const btnStartPause = document.getElementById("meditacao-startPauseBtn");
  const btnReset = document.getElementById("meditacao-resetBtn");
  const btnSound = document.getElementById("meditacao-soundBtn");
  const btnClose = document.getElementById("meditacao-closeBtn");
  const progressBar = document.getElementById("meditacao-progressBar");
  
  // Elementos de Texto
  const textoSubtitulo = document.getElementById("meditacao-subtitle");
  const textoDescricao = document.getElementById("meditacao-descricao");

  // --- Variáveis de Controle ---
  let intervaloTimer = null;
  let tempoTotal = 300; // Padrão 5 min
  let tempoRestante = 300;
  let estaRodando = false;
  let estaPausado = false;
  let somAtivado = true;

  // Mapa de descrições para cada tipo
  const descricoes = {
    "Mindfulness": "Foque na sua respiração natural, observando sem julgamento cada inspiração e expiração.",
    "Respiração 4-7-8": "Técnica calmante: Inspire pelo nariz (4s), segure (7s) e solte pela boca (8s).",
    "Relaxamento Muscular": "Contraia e relaxe progressivamente cada grupo muscular, dos pés à cabeça."
  };

  // --- Funções Auxiliares ---

  // Formata segundos em MM:SS
  function formatarTempo(segundos) {
    const min = String(Math.floor(segundos / 60)).padStart(2, "0");
    const seg = String(segundos % 60).padStart(2, "0");
    return `${min}:${seg}`;
  }

  // Atualiza a tela (Tempo e Barra de Progresso)
  function atualizarInterface() {
    displayTempo.textContent = formatarTempo(tempoRestante);
    
    // Cálculo da porcentagem da barra
    const porcentagem = tempoTotal > 0 ? ((tempoTotal - tempoRestante) / tempoTotal) * 100 : 0;
    progressBar.style.width = `${porcentagem}%`;
  }

  // Atualiza textos quando muda o select
  function atualizarInformacoes() {
    const tipo = selectTipo.value;
    const duracaoTexto = selectDuracao.options[selectDuracao.selectedIndex].text;
    
    textoSubtitulo.textContent = `${tipo} • ${duracaoTexto}`;
    textoDescricao.textContent = descricoes[tipo] || "Relaxe e concentre-se.";
    
    // Se não estiver rodando, atualiza o timer visualmente também
    if (!estaRodando && !estaPausado) {
      tempoTotal = parseInt(selectDuracao.value);
      tempoRestante = tempoTotal;
      atualizarInterface();
    }
  }

  // --- Lógica do Timer ---

  function iniciar() {
    if (!estaRodando) {
      // Início fresco
      tempoTotal = parseInt(selectDuracao.value);
      tempoRestante = tempoTotal;
      estaRodando = true;
      estaPausado = false;
    } else {
      // Retomada
      estaPausado = false;
    }

    btnStartPause.textContent = "⏸ Pausar";
    selectDuracao.disabled = true; // Trava mudanças durante o timer
    selectTipo.disabled = true;

    intervaloTimer = setInterval(() => {
      if (tempoRestante > 0) {
        tempoRestante--;
        atualizarInterface();
      } else {
        finalizar();
      }
    }, 1000);
  }

  function pausar() {
    clearInterval(intervaloTimer);
    estaPausado = true;
    btnStartPause.textContent = "▶ Retomar";
  }

  function finalizar() {
    clearInterval(intervaloTimer);
    estaRodando = false;
    estaPausado = false;
    displayTempo.textContent = "Namastê 🙏";
    progressBar.style.width = "100%";
    btnStartPause.textContent = "▶ Iniciar";
    selectDuracao.disabled = false;
    selectTipo.disabled = false;
    
    // Tocar som se ativado (simulação visual)
    if(somAtivado) {
        btnSound.style.transform = "scale(1.2)";
        setTimeout(() => btnSound.style.transform = "scale(1)", 500);
    }
  }

  function resetar() {
    clearInterval(intervaloTimer);
    estaRodando = false;
    estaPausado = false;
    selectDuracao.disabled = false;
    selectTipo.disabled = false;
    btnStartPause.textContent = "▶ Iniciar";
    
    // Reseta para os valores do select atual
    atualizarInformacoes(); 
    progressBar.style.width = "0%";
  }

  function fecharModal() {
    resetar(); // Reseta para não ficar rodando oculto
    modal.style.display = "none";
  }

  // --- Event Listeners ---

  // Botão Iniciar/Pausar
  btnStartPause.addEventListener("click", () => {
    if (estaRodando && !estaPausado) {
      pausar();
    } else {
      iniciar();
    }
  });

  // Botão Reset
  btnReset.addEventListener("click", resetar);

  // Botão Fechar (dentro do modal)
  btnClose.addEventListener("click", fecharModal);

  // Botão Som (apenas visual por enquanto)
  btnSound.addEventListener("click", () => {
    somAtivado = !somAtivado;
    btnSound.textContent = somAtivado ? "🔊" : "🔇";
  });

  // Mudança nos Selects
  selectDuracao.addEventListener("change", atualizarInformacoes);
  selectTipo.addEventListener("change", atualizarInformacoes);

  // Botão X do canto superior (assumindo classe .close)
  const spanClose = modal.querySelector(".close");
  if(spanClose) spanClose.addEventListener("click", fecharModal);
  
  // Clicar fora fecha
  window.addEventListener("click", (e) => {
    if (e.target === modal) fecharModal();
  });

  // Inicialização
  atualizarInformacoes();
});

document.addEventListener("DOMContentLoaded", () => {
  console.log("Script Diário Iniciado..."); // Para confirmar que carregou

  // --- SELEÇÃO DE ELEMENTOS ---
  const modal = document.getElementById("modal-gratidao");
  const btnAbrir = document.getElementById("btn-abrir-gratidao"); // Botão novo
  const btnFechar = document.getElementById("close-gratidao");
  const textoInput = document.getElementById("texto-gratidao");
  const btnSalvar = document.getElementById("btn-salvar-gratidao");
  const listaHistorico = document.getElementById("lista-gratidao");
  const btnLimpar = document.getElementById("btn-limpar-tudo");
  const btnDica = document.getElementById("btn-nova-ideia");
  const promptText = document.getElementById("gratidao-prompt");

  // Se não achar o modal, para o script para não dar erro
  if (!modal) {
    console.error("Erro: Modal de gratidão não encontrado no HTML");
    return;
  }

  // --- 1. ABRIR E FECHAR MODAL ---
  if (btnAbrir) {
    btnAbrir.addEventListener("click", () => {
      modal.style.display = "flex"; // Ou 'block', dependendo do seu CSS
      atualizarLista(); // Carrega a lista ao abrir
    });
  }

  if (btnFechar) {
    btnFechar.addEventListener("click", () => {
      modal.style.display = "none";
    });
  }

  // Fechar clicando fora
  window.addEventListener("click", (e) => {
    if (e.target === modal) modal.style.display = "none";
  });

  // --- 2. GUIA EXTRA (DICAS) ---
  const ideias = [
    "Alguém que te fez sorrir hoje...",
    "Uma comida gostosa que você comeu...",
    "Uma música que você ouviu...",
    "Um conforto da sua casa...",
    "Uma meta que você alcançou...",
    "O clima de hoje...",
    "Sua saúde ou corpo...",
    "Um amigo ou familiar..."
  ];

  if (btnDica) {
    btnDica.addEventListener("click", () => {
      const random = Math.floor(Math.random() * ideias.length);
      promptText.textContent = ideias[random];
      textoInput.value = ""; 
      textoInput.placeholder = `Ex: ${ideias[random]}`;
    });
  }

  // --- 3. BANCO DE DADOS (LOCALSTORAGE) ---
  let registros = JSON.parse(localStorage.getItem("diarioGratidao")) || [];

  function salvarNoStorage() {
    localStorage.setItem("diarioGratidao", JSON.stringify(registros));
  }

  // --- 4. RENDERIZAR LISTA ---
  function atualizarLista() {
    listaHistorico.innerHTML = "";

    if (registros.length === 0) {
      listaHistorico.innerHTML = "<li style='color:#ccc; text-align:center;'>Nenhum registro ainda.</li>";
      return;
    }

    // Cria a lista invertida (mais novo primeiro)
    registros.slice().reverse().forEach((item, indexInvertido) => {
      // Cálculo do índice real no array original para poder deletar corretamente
      const indexReal = registros.length - 1 - indexInvertido;

      const li = document.createElement("li");
      li.innerHTML = `
        <div>
            <span class="data-entry" style="display:block; font-size:11px; color:#888;">${item.data}</span>
            <span class="texto-entry">${item.texto}</span>
        </div>
        <button class="btn-delete-item" data-index="${indexReal}" style="color:red; background:none; border:none; cursor:pointer; font-weight:bold;">&times;</button>
      `;
      listaHistorico.appendChild(li);
    });

    // Adiciona eventos aos botões de excluir (Melhor que onclick no HTML)
    document.querySelectorAll(".btn-delete-item").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const idx = e.target.getAttribute("data-index");
        removerItem(idx);
      });
    });
  }

  // --- 5. SALVAR ---
  if (btnSalvar) {
    btnSalvar.addEventListener("click", () => {
      const texto = textoInput.value.trim();
      if (!texto) {
        alert("Por favor, escreva algo!");
        return;
      }

      const agora = new Date();
      const dataFormatada = agora.toLocaleDateString("pt-BR", {
        day: "2-digit", month: "long", hour: "2-digit", minute: "2-digit"
      });

      registros.push({ texto: texto, data: dataFormatada });
      salvarNoStorage();
      atualizarLista();
      textoInput.value = ""; // Limpar campo
      
      // Efeito visual no botão
      const textoOriginal = btnSalvar.textContent;
      btnSalvar.textContent = "Salvo! ✅";
      setTimeout(() => btnSalvar.textContent = textoOriginal, 2000);
    });
  }

  // --- 6. REMOVER ---
  function removerItem(index) {
    if (confirm("Apagar este registro?")) {
      registros.splice(index, 1);
      salvarNoStorage();
      atualizarLista();
    }
  }

  if (btnLimpar) {
    btnLimpar.addEventListener("click", () => {
      if (confirm("Apagar TODO o histórico?")) {
        registros = [];
        salvarNoStorage();
        atualizarLista();
      }
    });
  }

  // Carregar lista ao iniciar
  atualizarLista();
});

