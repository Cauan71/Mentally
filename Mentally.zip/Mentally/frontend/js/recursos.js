// localStorage Usuario
document.addEventListener("DOMContentLoaded", () => {
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (usuario && usuario.nome) {
        document.getElementById("nome-usuario").textContent = usuario.nome;
    }
});

const btnMobile = document.getElementById('btn-mobile');
const nav = document.getElementById('nav');
const menu = document.getElementById('menu');
const desktopSocial = document.getElementById('navigation_social');
const desktopIcons = document.getElementById('icons');
const desktopTitle = document.getElementById('title');
const hamburger = document.getElementById('hamburger');

btnMobile.addEventListener('click', toggleMenu);
btnMobile.addEventListener('touchstart', toggleMenu);

function toggleMenu(event) {
  if (event.type === 'touchstart') event.preventDefault();

  nav.classList.toggle('active');
  hamburger.classList.toggle('active');

  const active = nav.classList.contains('active');
  event.currentTarget.setAttribute('aria-expanded', active);
  event.currentTarget.setAttribute('aria-label', active ? 'Fechar Menu' : 'Abrir Menu');

  // Quando abrir o menu mobile
  if (active && window.innerWidth <= 1100) {
    // Adiciona o título
    if (!document.getElementById('mobile-title')) {
      const mobileTitle = desktopTitle.cloneNode(true);
      mobileTitle.id = 'mobile-title';
      menu.prepend(mobileTitle);
    }

    
    // Adiciona os ícones sociais
    if (!document.getElementById('mobile-social')) {
      const mobileSocial = desktopSocial.cloneNode(true);
      mobileSocial.id = 'mobile-social';
      menu.appendChild(mobileSocial);
    }
    
    // Adiciona os ícones
    if (!document.getElementById('mobile-icons')) {
      const mobileIcons = desktopIcons.cloneNode(true);
      mobileIcons.id = 'mobile-icons';
      menu.appendChild(mobileIcons);
    }
  }

  // Quando fechar o menu mobile
  if (!active) {
    const mobileTitle = document.getElementById('mobile-title');
    const mobileSocial = document.getElementById('mobile-social');
    const mobileIcons = document.getElementById('mobile-icons');

    if (mobileTitle) mobileTitle.remove();
    if (mobileSocial) mobileSocial.remove();
    if (mobileIcons) mobileIcons.remove();
  }
}



//modo escuro- modo claro
const chk = document.getElementById('checkbox');
const logo = document.getElementById('logo'); // agora pega o <img>


// Verifica se já tem preferência salva e aplica
if(localStorage.getItem('modo') === 'dark'){
  document.body.classList.add('dark');
  chk.checked = true;
  logo.src = "/img/mentaally colorido.png"; // versão clara
} else {
  logo.src = "/img/mentaally.png"; // versão escuraa
}

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  
  if(document.body.classList.contains('dark')){
    localStorage.setItem('modo', 'dark');
    logo.src = "/img/mentaally colorido.png"; // troca p/ dark

  } else {
    localStorage.setItem('modo', 'light');
    logo.src = "/img/mentaally.png"; // volta p/ light
  
  }
});

// ===== Modal =====
const modal = document.getElementById("modal");
const modalBody = document.getElementById("modal-body");
const closeModal = document.getElementById("close-modal");

function openModal(content) {
  modalBody.innerHTML = content;
  modal.style.display = "block";
}

closeModal.onclick = () => modal.style.display = "none";
window.onclick = (e) => { if (e.target === modal) modal.style.display = "none"; };

// ===== Conteúdos personalizados para cada card =====
const modalContents = {
  "Como Identificar Sinais de Ansiedade": {
    title: "Como Identificar Sinais de Ansiedade",
    desc: "Principais sintomas físicos, emocionais e comportamentais",
    extra: `
      <h2>1 - Sintomas Físicos</h2>
      <ul>
        <li>Batimentos cardíacos acelerados.</li>
        <li>Respiração curta ou sensação de falta de ar.</li>
        <li>Tremores, suor excessivo ou mãos frias.</li>
        <li>Tensão muscular (ombros, pescoço, costas).</li>
        <li>Distúrbios no sono (dificuldade para dormir ou sono agitado).</li>
      </ul>

      <h2>2 - Sintomas Emocionais</h2>
      <ul>
        <li>Preocupação constante e pensamentos acelerados.</li>
        <li>Irritabilidade ou impaciência.</li>
        <li>Sensação de medo ou pânico sem motivo aparente.</li>
        <li>Dificuldade de concentração.</li>
      </ul>

      <h2>3 - Sintomas Comportamentais</h2>
      <ul>
        <li>Evitar situações sociais ou de responsabilidade.</li>
        <li>Agitação (não conseguir ficar parado).</li>
        <li>Uso excessivo de distrações (celular, comida, etc.).</li>
        <li>Procrastinação por medo de falhar.</li>
      </ul>

      <p>👉 Reconhecer esses sinais é o primeiro passo para buscar equilíbrio e, se necessário, ajuda profissional.</p>
    `,
    badge: "Ansiedade",
    time: "5 min",
    date: "28/08/2025"
  },

  "Técnicas de Respiração para Controlar a Ansiedade": {
    title: "Técnicas de Respiração para Controlar a Ansiedade",
    desc: "",
    extra: `
      <h2>1 - Respiração 4-4-4 (Box Breathing)</h2>
      <ul>
        <li>Inspire pelo nariz contando 4 segundos.</li>
        <li>Segure o ar por 4 segundos.</li>
        <li>Expire lentamente pela boca em 4 segundos.</li>
        <li>Repita de 4 a 6 vezes.</li>
      </ul>
      <p class="dica">👉 Ótima para acalmar a mente rapidamente.</p>

      <h2>2 - Respiração Diafragmática (ou abdominal)</h2>
      <ul>
        <li>Coloque uma mão no peito e outra na barriga.</li>
        <li>Inspire profundamente pelo nariz, enchendo a barriga primeiro (não o peito).</li>
        <li>Expire devagar pela boca, esvaziando o abdômen.</li>
        <li>Repita por 5 minutos.</li>
      </ul>
      <p class="dica">👉 Excelente para relaxar e diminuir a tensão muscular.</p>
    `,
    badge: "Ansiedade",
    time: "7 min",
    date: "28/08/2025"
  },

  "Estratégias para Lidar com a Depressão": {
    title: "Estratégias para Lidar com a Depressão",
    desc: "Práticas simples que ajudam no bem-estar emocional e físico",
    extra: `
      <h2>1 - Cuidados com o Corpo</h2>
      <ul>
        <li>Manter uma rotina de sono regular.</li>
        <li>Praticar atividade física leve ou moderada (caminhadas já ajudam muito).</li>
        <li>Ter uma alimentação equilibrada e beber bastante água.</li>
      </ul>

      <h2>2 - Cuidados com a Mente</h2>
      <ul>
        <li>Praticar técnicas de respiração ou meditação.</li>
        <li>Registrar sentimentos em um diário (escrita terapêutica).</li>
        <li>Evitar excesso de notícias ou redes sociais quando sobrecarregarem.</li>
      </ul>

      <h2>3 - Conexão Social</h2>
      <ul>
        <li>Conversar com familiares ou amigos de confiança.</li>
        <li>Buscar apoio em grupos de interesse ou comunidades positivas.</li>
        <li>Não se isolar totalmente — pequenas interações já fazem diferença.</li>
      </ul>

      <h2>4 - Ajuda Profissional</h2>
      <ul>
        <li>Consultar um psicólogo para acompanhamento contínuo.</li>
        <li>Procurar um psiquiatra caso os sintomas sejam intensos.</li>
        <li>Seguir corretamente tratamentos recomendados.</li>
      </ul>

      <p>👉 Lembre-se: lidar com a depressão é um processo, e cada pequeno passo conta. Buscar ajuda não é fraqueza, é coragem.</p>
    `,
    badge: "Depressão",
    time: "7 min",
    date: "28/08/2025"
  },

  "Como Melhorar o Bem-estar no Dia a Dia": {
    title: "Como Melhorar o Bem-estar no Dia a Dia",
    desc: "Pequenos hábitos que trazem equilíbrio físico, mental e emocional",
    extra: `
      <h2>1 - Hábitos Saudáveis</h2>
      <ul>
        <li>Durma de 7 a 8 horas por noite para restaurar as energias.</li>
        <li>Pratique atividade física regularmente (mesmo caminhadas leves ajudam).</li>
        <li>Mantenha uma alimentação equilibrada e beba bastante água.</li>
      </ul>

      <h2>2 - Bem-estar Mental</h2>
      <ul>
        <li>Faça pausas ao longo do dia para respirar fundo ou meditar.</li>
        <li>Escreva pensamentos e metas em um diário para organizar a mente.</li>
        <li>Reduza o tempo em redes sociais quando sentir sobrecarga.</li>
      </ul>

      <h2>3 - Relações e Conexão</h2>
      <ul>
        <li>Converse com amigos ou familiares de confiança.</li>
        <li>Compartilhe momentos, mesmo que simples, com pessoas queridas.</li>
        <li>Pratique a gratidão: lembre-se diariamente de algo bom que aconteceu.</li>
      </ul>

      <h2>4 - Autocuidado e Lazer</h2>
      <ul>
        <li>Reserve um tempo para atividades que você gosta (ler, ouvir música, caminhar).</li>
        <li>Experimente algo novo de vez em quando (um hobby, um prato diferente, uma trilha).</li>
        <li>Pratique a gentileza consigo mesmo, sem cobranças excessivas.</li>
      </ul>

      <p>👉 O bem-estar diário vem da soma de pequenas escolhas. Cuidar de si é o primeiro passo para ter mais energia, equilíbrio e alegria.</p>
    `,
    badge: "Bem-estar",
    time: "7 min",
    date: "28/08/2025"
  }
};

   
  


// ===== Abrir modal dinamicamente com conteúdo personalizado =====
document.querySelectorAll(".open-modal").forEach(btn => {
  btn.addEventListener("click", () => {
    const card = btn.closest(".article-card, .quick-card");
    const key = card.querySelector("h3").textContent.trim(); // pega o título do h3 como chave
    const content = modalContents[key];

    if (content) {
      openModal(`
        <h2>${content.title}</h2>
        <p>${content.desc}</p>
        ${content.extra || ""}
        <p><em>${content.date} • ${content.time}</em></p>
        <span class="badge ${content.badge}">${content.badge}</span>
      `);
    } else {
      // fallback caso não encontre o conteúdo
      openModal(`
        <h2>${card.dataset.title || "Sem título"}</h2>
        <p>${card.dataset.desc || "Sem descrição"}</p>
      `);
    }
  });
});

    // ===== Filtros =====
    document.querySelectorAll(".filters button").forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".filters button").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        const filter = btn.dataset.filter;

        document.querySelectorAll(".article-card").forEach(card => {
          card.style.display = (filter === "Todos" || card.dataset.category === filter) ? "block" : "none";
        });
      });
    });

    // ===== Busca =====
    document.getElementById("search").addEventListener("input", e => {
      const search = e.target.value.toLowerCase();
      document.querySelectorAll(".article-card").forEach(card => {
        const match = card.dataset.title.toLowerCase().includes(search) || card.dataset.desc.toLowerCase().includes(search);
        card.style.display = match ? "block" : "none";
      });
    });