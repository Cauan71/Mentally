// ================== LOCALSTORAGE USUÁRIO ==================
document.addEventListener("DOMContentLoaded", () => {
  const usuario = JSON.parse(localStorage.getItem("usuario"));
  if (usuario && usuario.nome) {
    const nomeUsuario = document.getElementById("nome-usuario");
    if (nomeUsuario) nomeUsuario.textContent = usuario.nome;
  }
});

// ================== DARK MODE / LIGHT MODE ==================
const chk = document.getElementById("checkbox");
const logo = document.getElementById("logo"); // pega o <img> do logo

// Aplica preferência salva
if (localStorage.getItem("modo") === "dark") {
  document.body.classList.add("dark");
  if (chk) chk.checked = true;
  if (logo) logo.src = "/img/mentaally colorido.png"; // versão clara
} else {
  if (logo) logo.src = "/img/mentaally.png"; // versão escura
}

if (chk) {
  chk.addEventListener("change", () => {
    document.body.classList.toggle("dark");

    if (document.body.classList.contains("dark")) {
      localStorage.setItem("modo", "dark");
      if (logo) logo.src = "/img/mentaally colorido.png";
    } else {
      localStorage.setItem("modo", "light");
      if (logo) logo.src = "/img/mentaally.png";
    }
  });
}

// ================== MENU HAMBÚRGUER ==================
const btnMobile = document.getElementById("btn-mobile");
const nav = document.getElementById("nav");
const menu = document.getElementById("menu");
const iconsOriginal = document.getElementById("icons"); // ícones principais
const desktopSocial = document.getElementById("desktop-social");
const desktopTitle = document.getElementById("title");
const hamburger = document.getElementById("hamburger");

function toggleMenu(event) {
  if (event.type === "touchstart") event.preventDefault();

  nav.classList.toggle("active");
  hamburger.classList.toggle("active");

  const active = nav.classList.contains("active");
  event.currentTarget.setAttribute("aria-expanded", active);
  event.currentTarget.setAttribute(
    "aria-label",
    active ? "Fechar Menu" : "Abrir Menu"
  );

  // ========== Abrindo menu ==========
  if (active && window.innerWidth <= 1100) {
    // Título mobile
    if (!document.getElementById("mobile-title") && desktopTitle) {
      const mobileTitle = desktopTitle.cloneNode(true);
      mobileTitle.id = "mobile-title";
      menu.prepend(mobileTitle);
    }

    // Ícones sociais mobile
    if (!document.getElementById("mobile-social") && desktopSocial) {
      const mobileSocial = desktopSocial.cloneNode(true);
      mobileSocial.id = "mobile-social";
      menu.appendChild(mobileSocial);
    }

    // Ícones principais mobile
    if (!document.getElementById("mobile-icons") && iconsOriginal) {
      const mobileIcons = iconsOriginal.cloneNode(true);
      mobileIcons.id = "mobile-icons";
      menu.appendChild(mobileIcons);
    }
  }

  // ========== Fechando menu ==========
  if (!active) {
    const mobileTitle = document.getElementById("mobile-title");
    const mobileSocial = document.getElementById("mobile-social");
    const mobileIcons = document.getElementById("mobile-icons");

    if (mobileTitle) mobileTitle.remove();
    if (mobileSocial) mobileSocial.remove();
    if (mobileIcons) mobileIcons.remove();
  }
}

if (btnMobile) {
  btnMobile.addEventListener("click", toggleMenu);
  btnMobile.addEventListener("touchstart", toggleMenu);
}

// ================== LOGOUT (Profissionais) ==================
const logoutBtn = document.getElementById("logoutBtn");
if (logoutBtn) {
  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("usuario"); // remove o usuário
    localStorage.removeItem("modo");    // limpa preferência de modo
    window.location.href = "/login.html"; // redireciona para login
  });
}
