document.addEventListener("DOMContentLoaded", () => {

    // =================================================================
    // 1. BANCO DE DADOS DE MENSAGENS (EXPANDIDO)
    // =================================================================
    const insightsPorHumor = {
        // Frases para quando ainda não houve check-in ou estado genérico
        "generico": [
            "A prática da gratidão por apenas 5 minutos diários aumenta seu bem-estar.",
            "Respire fundo. O momento presente é o único que você realmente tem.",
            "Pequenas pausas durante o dia restauram sua energia mental.",
            "Você é capaz de lidar com mais coisas do que imagina.",
            "Cuide de si mesmo com a mesma gentileza que cuida dos outros.",
            "Não se compare com o palco dos outros. Respeite seus bastidores.",
            "O progresso não é uma linha reta. Altos e baixos fazem parte.",
            "Sua saúde mental é uma prioridade, não um luxo.",
            "Aprender a dizer 'não' é uma forma de dizer 'sim' para si mesmo.",
            "Hoje é uma nova oportunidade para recomeçar, não importa o ontem."
        ],
        // Para: 😊 (Excelente) e 🙂 (Bem)
        "feliz": [
            "Que energia boa! Aproveite para espalhar sorrisos hoje.",
            "Guarde esse sentimento: ele é a prova de que dias bons existem.",
            "Use essa motivação para tirar aquele projeto do papel.",
            "A felicidade se multiplica quando é compartilhada.",
            "Celebre suas vitórias, você merece esse momento de alegria!",
            "Sua luz hoje pode iluminar o dia de alguém que precisa.",
            "Aproveite essa clareza mental para definir novas metas.",
            "Registre o que te fez bem hoje para reler em dias difíceis.",
            "A gratidão transforma o que temos em suficiente.",
            "Você está colhendo os frutos do seu autocuidado. Parabéns!"
        ],
        // Para: 😐 (Neutro)
        "neutro": [
            "Dias neutros são importantes para o equilíbrio. Não se cobre tanto.",
            "A calmaria é um ótimo momento para colocar os pensamentos em ordem.",
            "Tudo bem não estar eufórico o tempo todo. A estabilidade é valiosa.",
            "Aproveite a tranquilidade para focar no que é essencial.",
            "Respire e siga seu ritmo, um passo de cada vez.",
            "O tédio ou a neutralidade podem ser o berço da criatividade.",
            "Um dia normal é um presente. Aproveite a simplicidade.",
            "Não force sentimentos. Apenas esteja presente no agora.",
            "A constância é mais importante que a intensidade.",
            "Use hoje para descansar a mente e preparar o terreno para o amanhã."
        ],
        // Para: 😔 (Triste)
        "triste": [
            "Está tudo bem não estar bem o tempo todo. Respeite seu tempo.",
            "Lembre-se: nenhum inverno dura para sempre. Isso também vai passar.",
            "Se acolha hoje. Um chá quente e descanso também são produtividade.",
            "Chorar faz parte da cura. Não guarde tudo para você.",
            "Você é mais forte do que esse momento difícil.",
            "Não acredite em tudo que seus pensamentos negativos dizem agora.",
            "Seja gentil consigo mesmo hoje, como seria com seu melhor amigo.",
            "Dê um pequeno passo hoje, nem que seja sair da cama. Já é uma vitória.",
            "Amanhã o sol nasce de novo, trazendo novas perspectivas.",
            "Sua dor é válida, mas ela não define quem você é."
        ],
        // Para: 😰 (Ansioso)
        "ansioso": [
            "Concentre-se apenas na próxima tarefa, não na escada inteira.",
            "Inspire em 4 segundos, segure 7, expire em 8. O controle está na respiração.",
            "A maioria das coisas que nos preocupam nunca chegam a acontecer.",
            "Desconecte-se um pouco. O mundo pode esperar 10 minutos.",
            "Aterre seus pés no chão e sinta o agora. Você está seguro.",
            "Faça uma lista do que está sob seu controle e solte o resto.",
            "A ansiedade mente para você. Você está mais seguro do que sente.",
            "Evite cafeína hoje e tente beber mais água.",
            "Foque em seus 5 sentidos: o que você vê, ouve e toca agora?",
            "Um passo de cada vez. Não precisa resolver a vida toda hoje."
        ]
    };

    // =================================================================
    // 2. FUNÇÕES AUXILIARES E LÓGICA DO INSIGHT
    // =================================================================

    // Traduz o emoji clicado para a chave do objeto de mensagens
    function identificarCategoriaHumor(emoji) {
        if (emoji === '😊' || emoji === '🙂') return 'feliz';
        if (emoji === '😐') return 'neutro';
        if (emoji === '😔') return 'triste';
        if (emoji === '😰') return 'ansioso';
        return 'generico';
    }

    // Exibe a mensagem baseada no dia e no humor
    function showDailyInsight() {
        const today = new Date().toLocaleDateString();
        
        // Recupera histórico
        let localHistory = JSON.parse(localStorage.getItem('moodHistory')) || [];
        const lastEntry = localHistory.length > 0 ? localHistory[0] : null;
        const temRegistroHoje = lastEntry && lastEntry.date === today;

        let categoria = 'generico';

        if (temRegistroHoje) {
            categoria = identificarCategoriaHumor(lastEntry.emoji);
        }

        const listaFrases = insightsPorHumor[categoria] || insightsPorHumor['generico'];

        // --- LÓGICA ANTI-REPETIÇÃO ---
        // Calcula o "Dia do Ano" (1 a 366)
        const dateObj = new Date();
        const start = new Date(dateObj.getFullYear(), 0, 0);
        const diff = dateObj - start;
        const oneDay = 1000 * 60 * 60 * 24;
        const dayOfYear = Math.floor(diff / oneDay);

        // Usa o dia do ano como índice. 
        // Exemplo: Dia 1 pega a frase 1, Dia 2 pega a frase 2.
        // O operador % (resto da divisão) faz voltar para a frase 0 quando a lista acaba.
        // Isso garante que a frase mude todo dia e siga uma sequência sem repetir aleatoriamente.
        const insightIndex = dayOfYear % listaFrases.length;

        const insightElement = document.getElementById('daily-insight');
        if (insightElement) {
            insightElement.style.opacity = 0;
            setTimeout(() => {
                insightElement.textContent = listaFrases[insightIndex];
                insightElement.style.opacity = 1;
            }, 300);
        }
    }

    // =================================================================
    // 3. RECUPERAÇÃO DE DADOS DO USUÁRIO
    // =================================================================
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    if (usuario && usuario.nome) {
        document.querySelectorAll(".nome-usuario").forEach(el => {
            el.textContent = usuario.nome;
        });
    }

    // =================================================================
    // 4. MODO ESCURO (Dark Mode)
    // =================================================================
    const chk = document.getElementById('checkbox');
    const logos = document.querySelectorAll('.logo');

    function alterarLogos(caminhoImagem) {
        logos.forEach((img) => {
            img.src = caminhoImagem;
        });
    }

    if (localStorage.getItem('modo') === 'dark') {
        document.body.classList.add('dark');
        if (chk) chk.checked = true;
        alterarLogos("img/mentaally-colorido.png");
    } else {
        alterarLogos("img/mentaally.png");
    }

    if (chk) {
        chk.addEventListener('change', () => {
            document.body.classList.toggle('dark');
            if (document.body.classList.contains('dark')) {
                localStorage.setItem('modo', 'dark');
                alterarLogos("img/mentaally-colorido.png");
            } else {
                localStorage.setItem('modo', 'light');
                alterarLogos("img/mentaally.png");
            }
        });
    }

    // =================================================================
    // 5. MENU MOBILE
    // =================================================================
    const btnMobile = document.getElementById('btn-mobile');
    const nav = document.getElementById('nav');
    const menu = document.getElementById('menu');
    const desktopSocial = document.getElementById('navigation_social');
    const desktopIcons = document.getElementById('icons');
    const desktopTitle = document.getElementById('title');
    const hamburger = document.getElementById('hamburger');

    if (btnMobile) {
        function toggleMenu(event) {
            if (event.type === 'touchstart') event.preventDefault();
            nav.classList.toggle('active');
            hamburger.classList.toggle('active');
            const active = nav.classList.contains('active');
            event.currentTarget.setAttribute('aria-expanded', active);
            event.currentTarget.setAttribute('aria-label', active ? 'Fechar Menu' : 'Abrir Menu');

            if (active && window.innerWidth <= 1100) {
                if (!document.getElementById('mobile-title') && desktopTitle) {
                    const mobileTitle = desktopTitle.cloneNode(true);
                    mobileTitle.id = 'mobile-title';
                    menu.prepend(mobileTitle);
                }
                if (!document.getElementById('mobile-social') && desktopSocial) {
                    const mobileSocial = desktopSocial.cloneNode(true);
                    mobileSocial.id = 'mobile-social';
                    menu.appendChild(mobileSocial);
                }
                if (!document.getElementById('mobile-icons') && desktopIcons) {
                    const mobileIcons = desktopIcons.cloneNode(true);
                    mobileIcons.id = 'mobile-icons';
                    menu.appendChild(mobileIcons);
                }
            } else if (!active) {
                const mt = document.getElementById('mobile-title');
                const ms = document.getElementById('mobile-social');
                const mi = document.getElementById('mobile-icons');
                if (mt) mt.remove();
                if (ms) ms.remove();
                if (mi) mi.remove();
            }
        }
        btnMobile.addEventListener('click', toggleMenu);
        btnMobile.addEventListener('touchstart', toggleMenu);
    }

    // =================================================================
    // 6. RASTREADOR DE HUMOR (MOOD TRACKER)
    // =================================================================
    const moods = document.querySelectorAll('.mood');
    const btn = document.querySelector('.btn');
    const daysContainer = document.querySelector('.days');
    const messageEl = document.getElementById('message');
    let selectedMood = null;
    let history = JSON.parse(localStorage.getItem('moodHistory')) || [];

    function renderHistory() {
        if (!daysContainer) return;
        daysContainer.innerHTML = '';
        for (let i = 0; i < 7; i++) {
            const mood = history[i] || { emoji: '?', color: 'gray' };
            const div = document.createElement('div');
            // Garante que tenha uma classe de cor ou usa gray como fallback
            div.className = `day ${mood.color || 'gray'}`;
            div.textContent = mood.emoji;
            daysContainer.appendChild(div);
        }
    }

    function showMessage(text, type = 'success', duration = 3000) {
        if (!messageEl) return;
        messageEl.textContent = text;
        messageEl.className = `message show ${type}`;
        setTimeout(() => {
            messageEl.className = `message hide ${type}`;
        }, duration);
    }

    moods.forEach(mood => {
        mood.addEventListener('click', () => {
            moods.forEach(m => m.classList.remove('selected'));
            mood.classList.add('selected');
            selectedMood = {
                emoji: mood.querySelector('span').textContent,
                color: mood.dataset.color
            };
            if (btn) btn.disabled = false;
        });
    });

    if (btn) {
        btn.addEventListener('click', () => {
            if (!selectedMood) {
                showMessage("Você precisa escolher um humor!", "warning");
                return;
            }

            const today = new Date().toLocaleDateString();
            const lastEntry = history[0] ? history[0].date : null;

            if (lastEntry === today) {
                showMessage("Você já registrou seu humor hoje!", "error");
                return;
            }

            history.unshift({ ...selectedMood, date: today });
            if (history.length > 7) history.pop();
            localStorage.setItem('moodHistory', JSON.stringify(history));
            
            renderHistory();
            
            selectedMood = null;
            moods.forEach(m => m.classList.remove('selected'));
            btn.disabled = true;

            showMessage("Humor registrado com sucesso!", "success");
            
            // ATUALIZA A MENSAGEM DO DIA BASEADA NO NOVO HUMOR
            showDailyInsight();
        });
    }

    // Renderiza o histórico e a mensagem ao carregar a página
    renderHistory();
    showDailyInsight();

    // =================================================================
    // 7. EXERCÍCIO DE RESPIRAÇÃO
    // =================================================================
    const circle = document.getElementById('breathing-circle');
    const textBreathing = document.getElementById('breathing-text');
    
    if (circle && textBreathing) {
        let isActive = false;
        let currentPhase = 0;
        let timer;
        const phases = [
            { text: 'Inspire', duration: 4000 },
            { text: 'Segure', duration: 7000 },
            { text: 'Expire', duration: 8000 }
        ];

        circle.addEventListener('click', function() {
            if (!isActive) {
                isActive = true;
                circle.classList.add('active');
                runPhase();
            } else {
                isActive = false;
                circle.classList.remove('active');
                textBreathing.textContent = 'Iniciar';
                clearTimeout(timer);
                currentPhase = 0;
            }
        });

        function runPhase() {
            if (!isActive) return;
            const phase = phases[currentPhase];
            textBreathing.textContent = phase.text;
            timer = setTimeout(() => {
                currentPhase = (currentPhase + 1) % phases.length;
                if (isActive) runPhase();
            }, phase.duration);
        }
    }

    // =================================================================
    // 8. SLIDER DE TESTEMUNHOS
    // =================================================================
    const track = document.getElementById('testimonials-track');
    const dots = document.querySelectorAll('.nav-dot');
    
    if (track && dots.length > 0) {
        let currentSlide = 0;
        const totalSlides = dots.length;

        function goToSlide(slideIndex) {
            currentSlide = slideIndex;
            track.style.transform = `translateX(-${currentSlide * 100}%)`;
            dots.forEach((dot, index) => {
                dot.classList.toggle('active', index === currentSlide);
            });
        }

        dots.forEach((dot, index) => {
            dot.addEventListener('click', () => goToSlide(index));
        });

        setInterval(() => {
            const nextSlide = (currentSlide + 1) % totalSlides;
            goToSlide(nextSlide);
        }, 6000);
    }

    // =================================================================
    // 9. SCROLL SUAVE E ANIMAÇÕES
    // =================================================================
    // Header Scroll
    window.addEventListener('scroll', () => {
        const header = document.getElementById('header');
        if (header) {
            if (window.scrollY > 100) header.classList.add('header-scrolled');
            else header.classList.remove('header-scrolled');
        }
    });

    // Smooth Link Scroll
    document.querySelectorAll('a[href^="#"]').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                const headerHeight = document.getElementById('header') ? document.getElementById('header').offsetHeight : 0;
                window.scrollTo({
                    top: targetSection.offsetTop - headerHeight,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Scroll Animations (IntersectionObserver)
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

    document.querySelectorAll('.service-card, .blog-card, .hero-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });

    // =================================================================
    // 10. MODAIS
    // =================================================================
    // Funções globais para abrir modais se necessário chamar via HTML onclick
    window.openModal = function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    };

    window.closeModal = function(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = 'auto';
        }
    };

    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) window.closeModal(modal.getAttribute('id'));
        });
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const openModalEl = document.querySelector('.modal.show');
            if (openModalEl) window.closeModal(openModalEl.getAttribute('id'));
        }
    });

    // =================================================================
    // 11. ÁREA DE MENSAGEM DO DIA & COMPARTILHAMENTO
    // (Lógica secundária para seção de rodapé ou extra)
    // =================================================================
    const mensagemEl = document.querySelector(".mensagem");
    const shareBtn = document.getElementById("shareBtn");
    const saveBtn = document.getElementById("saveBtn");

    if (mensagemEl) {
        // Usa a mesma lógica de frases genéricas ou uma lista separada se preferir
        // Aqui estou usando uma lista simples para essa área específica
        const mensagensExtras = [
            "Você não precisa ter todas as respostas hoje.",
            "Um passo de cada vez já é progresso.",
            "Seja sua própria prioridade.",
            "Confie no processo da sua vida.",
            "Respire. Tudo vai se encaixar."
        ];
        
        const hojeIndex = new Date().getDate() % mensagensExtras.length;
        mensagemEl.innerText = mensagensExtras[hojeIndex];

        if (shareBtn) {
            shareBtn.addEventListener("click", () => {
                const text = mensagemEl.innerText;
                if (navigator.share) {
                    navigator.share({ text }).catch(console.error);
                } else {
                    alert("Copiado: " + text);
                    navigator.clipboard.writeText(text);
                }
            });
        }

        if (saveBtn) {
            saveBtn.addEventListener("click", () => {
                const text = mensagemEl.innerText;
                const blob = new Blob([text], { type: "text/plain" });
                const a = document.createElement("a");
                a.href = URL.createObjectURL(blob);
                a.download = "reflexao.txt";
                a.click();
            });
        }
    }
});