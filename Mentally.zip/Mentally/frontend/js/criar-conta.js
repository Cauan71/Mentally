

const chk = document.getElementById('checkbox');

// modo escuro
if(localStorage.getItem('modo') === 'dark'){
  document.body.classList.add('dark');
  chk.checked = true;
}

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  if(document.body.classList.contains('dark')){
    localStorage.setItem('modo', 'dark');
  } else {
    localStorage.setItem('modo', 'light');
  }
});

// envio para backend
document.getElementById("form").addEventListener("submit", function(e){
    e.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();
    const name = document.getElementById("name").value.trim();
    const confirmarSenha = document.getElementById("confirmar-senha").value.trim();
    const terms = document.getElementById("terms").checked;

    // validações
    if (!email.includes("@")) { alert("Digite um e-mail válido."); return; }
    if (password.length < 6) { alert("A senha deve ter no mínimo 6 caracteres."); return; }
    if (name.length < 3) { alert("Nome deve ter no mínimo 3 caracteres."); return; }
    if (confirmarSenha !== password){ alert("As senhas não conferem."); return; }
    if (!terms) { alert("Você precisa aceitar os termos e condições."); return; }

    // envia para Node.js
    fetch("http://localhost:3001/usuarios", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            nome_usuario: name,
            email_usuario: email,
            senha_usuario: password
        })
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message || "Cadastro realizado com sucesso!");
        window.location.href = "login.html";
    })
    .catch(err => {
        console.error(err);
        alert("Erro ao cadastrar usuário. Tente novamente.");
    });
});


// ===== LOGIN COM GOOGLE =====
  window.handleCredentialResponse = async function (response) {
    try {
      const token = response.credential;

      // Decodifica o token JWT do Google
      const payload = JSON.parse(atob(token.split(".")[1]));

      const email = payload.email;
      const nome = payload.name;
      const foto = payload.picture;

      // Envia ao backend
      const res = await fetch("http://localhost:3001/auth/google", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token,
          email,
          nome,
          foto
        })
      });

      const data = await res.json();
      console.log("Resposta Google Login:", data);

      if (!data.success) {
        alert(data.message || "Erro no login com Google.");
        return;
      }

      // LOGIN COMO USUÁRIO
      if (data.tipo === "usuario") {
        localStorage.setItem("usuario", JSON.stringify(data.usuario));

        if (!data.usuario.CPF || data.usuario.CPF.trim() === "") {
          alert("⚠️ Complete seu cadastro (CPF).");
          window.location.href = "Perfil.html";
        } else {
          alert(`Bem-vindo, ${data.usuario.nome_usuario}!`);
          window.location.href = "pagina_principal.html";
        }
      }

      /*// LOGIN COMO PROFISSIONAL
      if (data.tipo === "profissional") {
        localStorage.setItem("profissional", JSON.stringify(data.profissional));

        if (!data.profissional.sobre_mim || data.profissional.sobre_mim.trim() === "") {
          alert("⚠️ Complete seu cadastro profissional.");
          window.location.href = "perfil-profissional.html";
        } else {
          alert(`Bem-vindo, Dr(a). ${data.profissional.nome_profissional}!`);
          window.location.href = "profissional-principal.html";
        }
      }*/

    } catch (error) {
      console.error("Erro no Google Login:", error);
      alert("Erro ao autenticar com Google.");
    }
  };