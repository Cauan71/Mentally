document.addEventListener("DOMContentLoaded", () => {
  const chk = document.getElementById("checkbox");
  const nomeCompleto = document.getElementById("nomeCompleto");
  const nomeUsuarioHeader = document.getElementById("nome-usuario");
  const profileImage = document.getElementById("profileImage");
  const inputNome = document.getElementById("inputNome");
  const inputEmail = document.getElementById("inputEmail");
  const inputSobre = document.getElementById("inputSobreMim");
  const inputEspecialidade = document.getElementById("inputEspecialidade");
  const inputAreaAtuacao = document.getElementById("inputAreaAtuacao");
  const formPerfil = document.getElementById("formPerfil");
  const membroDesde = document.getElementById("membroDesde");

  const tabs = document.querySelectorAll(".tab-btn");
  const tabContents = document.querySelectorAll(".tab-content");

  // ===== FUNÇÃO PARA NORMALIZAR TEXTO =====
  function normalizar(texto) {
    return texto
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim()
      .toLowerCase();
  }

  // ===== MODO ESCURO =====
  if (chk) {
    if (localStorage.getItem("modo") === "dark") {
      document.body.classList.add("dark");
      chk.checked = true;
    }
    chk.addEventListener("change", () => {
      document.body.classList.toggle("dark");
      localStorage.setItem(
        "modo",
        document.body.classList.contains("dark") ? "dark" : "light"
      );
    });
  }

  // ===== ABAS =====
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      const target = tab.getAttribute("data-tab");
      tabContents.forEach(tc => {
        tc.classList.remove("active");
        if (tc.id === target) tc.classList.add("active");
      });
    });
  });



  // ===== UPLOAD DE FOTO DE PERFIL =====
  const uploadInput = document.getElementById("uploadInput");

  if (uploadInput && profileImage) {

    // Ao clicar no botão de upload (📷)
    document.querySelector(".upload-btn").addEventListener("click", () => {
      uploadInput.click();
    });

    // Quando o usuário escolhe um arquivo
    uploadInput.addEventListener("change", async () => {
      const file = uploadInput.files[0];
      if (!file) return;

      const profissional = JSON.parse(localStorage.getItem("profissional"));
      if (!profissional) return alert("Nenhum profissional logado.");

      const id_profissional = profissional.idProfissional || profissional.id_profissional;

      const formData = new FormData();
      formData.append("avatar", file);
      formData.append("id_profissional", id_profissional);

      try {
        const res = await fetch("http://localhost:3001/profissionais/avatar", {
          method: "POST",
          body: formData
        });

        const data = await res.json();

        if (!res.ok) throw new Error(data.message || "Erro ao enviar foto.");

        // Atualiza visualmente a foto
        profileImage.src = data.url.startsWith("http")
          ? data.url + "?t=" + new Date().getTime()
          : "http://localhost:3001" + data.url + "?t=" + new Date().getTime();

        // Atualiza no localStorage
        profissional.avatar = data.url;
        localStorage.setItem("profissional", JSON.stringify(profissional));

        alert("Foto atualizada com sucesso!");

      } catch (err) {
        console.error("Erro ao fazer upload:", err);
        alert("Erro ao enviar foto: " + err.message);
      }
    });
  }


  // ===== CARREGAR LISTAS =====
  let especialidades = [];
  let areasAtuacao = [];
  let listasCarregadas = false;

  async function carregarListas() {
    try {
      const [resEsp, resArea] = await Promise.all([
        fetch("http://localhost:3001/especialidades"),
        fetch("http://localhost:3001/areasAtuacao")
      ]);
      if (resEsp.ok) especialidades = await resEsp.json();
      if (resArea.ok) areasAtuacao = await resArea.json();
      listasCarregadas = true;
    } catch (err) {
      console.error("Erro ao carregar listas:", err);
      listasCarregadas = false;
    }
  }
  carregarListas();

  // ===== CARREGAR DADOS DO PROFISSIONAL =====
  async function carregarDadosPerfil() {
    const profissional = JSON.parse(localStorage.getItem("profissional"));
    if (!profissional) {
      console.warn("Nenhum profissional logado encontrado.");
      if (profileImage) profileImage.src = "img/perfil siru.jpg";
      return;
    }

    if (nomeCompleto) nomeCompleto.textContent = profissional.nome_profissional || "Seu Nome";
    if (nomeUsuarioHeader) nomeUsuarioHeader.textContent = profissional.nome_profissional || "";
    if (inputNome) inputNome.value = profissional.nome_profissional || "";
    if (inputEmail) inputEmail.value = profissional.email_profissional || "";
    if (inputSobre) inputSobre.value = profissional.sobre_mim || "";

    if (membroDesde && profissional.membroDesde) {
      const data = new Date(profissional.membroDesde);
      membroDesde.textContent = `Membro desde ${data.toLocaleDateString("pt-BR")}`;
    }

    if (profileImage) {
      profileImage.src = profissional.avatar
        ? (profissional.avatar.startsWith("http") ? profissional.avatar : "http://localhost:3001" + profissional.avatar)
        : "img/perfil siru.jpg";
    }

    // Especialidade
    if (profissional.ESPECIALIDADE_especialidade_PK && inputEspecialidade) {
      try {
        const res = await fetch(`http://localhost:3001/especialidades/${profissional.ESPECIALIDADE_especialidade_PK}`);
        const data = await res.json();
        inputEspecialidade.value = data.especialidade || "";
      } catch (err) {
        console.error("Erro ao carregar especialidade:", err);
        inputEspecialidade.value = "";
      }
    }

    // Área de atuação
    if (profissional.AREA_ATUACAO_areaAtuacao_PK && inputAreaAtuacao) {
      try {
        const res = await fetch(`http://localhost:3001/areasAtuacao/${profissional.AREA_ATUACAO_areaAtuacao_PK}`);
        const data = await res.json();
        inputAreaAtuacao.value = data.areaAtuacao || "";
      } catch (err) {
        console.error("Erro ao carregar área de atuação:", err);
        inputAreaAtuacao.value = "";
      }
    }
  }
  carregarDadosPerfil();

  // ===== ATUALIZAR DADOS DO PERFIL =====
  if (formPerfil) {
    formPerfil.addEventListener("submit", async (e) => {
      e.preventDefault();
      if (!listasCarregadas) return alert("As listas ainda estão carregando. Tente novamente.");

      const profissional = JSON.parse(localStorage.getItem("profissional"));
      if (!profissional) return alert("Nenhum profissional logado.");

      const dadosAtualizados = {};

      // Nome e Sobre mim
      if (inputNome.value !== profissional.nome_profissional) dadosAtualizados.nome_profissional = inputNome.value;
      if ((inputSobre.value || "") !== (profissional.sobre_mim || "")) dadosAtualizados.sobre_mim = inputSobre.value;

      // Especialidade
      if (inputEspecialidade.value) {
        const especialidadeDigitada = normalizar(inputEspecialidade.value);
        const especialidadeEncontrada = especialidades.find(e => normalizar(e.especialidade) === especialidadeDigitada);

        if (especialidadeEncontrada) {
          dadosAtualizados.ESPECIALIDADE_especialidade_PK = especialidadeEncontrada.especialidade_PK;
        } else {
          dadosAtualizados.novaEspecialidade = inputEspecialidade.value;
        }
      }

      // Área de atuação
      if (inputAreaAtuacao.value) {
        const areaDigitada = normalizar(inputAreaAtuacao.value);
        const areaEncontrada = areasAtuacao.find(a => normalizar(a.areaAtuacao) === areaDigitada);

        if (areaEncontrada) {
          dadosAtualizados.AREA_ATUACAO_areaAtuacao_PK = areaEncontrada.areaAtuacao_PK;
        } else {
          dadosAtualizados.novaAreaAtuacao = inputAreaAtuacao.value;
        }
      }

      if (Object.keys(dadosAtualizados).length === 0) return alert("Nenhuma alteração foi feita.");

      try {
        const id = profissional.idProfissional || profissional.id_profissional;
        const res = await fetch(`http://localhost:3001/profissionais/${id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(dadosAtualizados)
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Erro ao atualizar perfil");

        if (data.profissional) {
          localStorage.setItem("profissional", JSON.stringify(data.profissional));
          Object.assign(profissional, data.profissional);
          alert("Alterações salvas com sucesso!");
        } else {
          alert("Erro: resposta inválida do servidor.");
        }
      } catch (err) {
        console.error(err);
        alert(`Erro ao salvar alterações: ${err.message}`);
      }
    });
  }

  // ===== ALTERAR SENHA =====
  const formSenha = document.getElementById("formSenha");
  if (formSenha) {
    formSenha.addEventListener("submit", async (e) => {
      e.preventDefault();
      const senhaAtual = document.getElementById("senhaAtual").value;
      const novaSenha = document.getElementById("novaSenha").value;
      const confirmaSenha = document.getElementById("confirmaNovaSenha").value;

      if (novaSenha !== confirmaSenha) {
        return alert("⚠️ As senhas não coincidem!");
      }

      const profissional = JSON.parse(localStorage.getItem("profissional"));
      if (!profissional) return alert("Nenhum profissional logado.");

      try {
        const id = profissional.idProfissional || profissional.id_profissional;
        const res = await fetch(`http://localhost:3001/profissionais/${id}/alterar-senha`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ senhaAtual, novaSenha })
        });
        const data = await res.json();
        if (res.ok) {
          alert(data.message || "Senha alterada com sucesso!");
          formSenha.reset();
        } else {
          alert(data.message || "Erro ao alterar senha.");
        }
      } catch (err) {
        console.error(err);
        alert("Erro ao alterar senha. Tente novamente mais tarde.");
      }
    });
  }

  // ===== EXCLUIR CONTA =====
  window.excluirConta = async () => {
    const profissional = JSON.parse(localStorage.getItem("profissional"));
    if (!profissional) return alert("Nenhum profissional logado.");
    if (!confirm("⚠️ Tem certeza que deseja excluir sua conta permanentemente?")) return;

    try {
      const id = profissional.idProfissional || profissional.id_profissional;
      const response = await fetch(`http://localhost:3001/profissionais/${id}`, { method: "DELETE" });
      const data = await response.json();

      if (response.ok) {
        alert(data.message || "Conta excluída com sucesso!");
        localStorage.removeItem("profissional");
        window.location.href = "index.html";
      } else {
        alert(data.message || "Erro ao excluir conta.");
      }
    } catch (err) {
      console.error(err);
      alert("❌ Falha na exclusão. Tente novamente mais tarde.");
    }
  };
});
