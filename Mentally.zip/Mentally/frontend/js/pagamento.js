document.addEventListener("DOMContentLoaded", () => {
  const btnPago = document.getElementById("btnPago");
  const pixScreen = document.getElementById("pixScreen");
  const successScreen = document.getElementById("successScreen");

  btnPago.addEventListener("click", () => {
    // Troca para a tela de sucesso
    pixScreen.classList.remove("active");
    successScreen.classList.add("active");

    // Aguarda alguns segundos e redireciona
    setTimeout(() => {
      window.location.href = "pagina_principal.html";
    }, 3000);
  });
});
