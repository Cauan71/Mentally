
// Alternar modo escuro
  const chk = document.getElementById('checkbox');
  if (localStorage.getItem('modo') === 'dark') {
    document.body.classList.add('dark');
    chk.checked = true;
  }

  chk.addEventListener('change', () => {
    document.body.classList.toggle('dark');
    localStorage.setItem('modo', document.body.classList.contains('dark') ? 'dark' : 'light');
  });

  // Envio do formulário
  document.getElementById("formProfissional").addEventListener("submit", function(e) {
    e.preventDefault();

    const nome = document.getElementById("nome").value.trim();
    const email = document.getElementById("email").value.trim();
    const senha = document.getElementById("senha").value.trim();
    const confirmarSenha = document.getElementById("confirmarSenha").value.trim();
    const especialidade = document.getElementById("especialidade").value.trim();
    const areaAtuacao = document.getElementById("areaAtuacao").value.trim();
    const registroProfissional = document.getElementById("registroProfissional").value.trim();
    const terms = document.getElementById("termsProfissional").checked;

    if (nome.length < 3) return alert("Nome deve ter no mínimo 3 caracteres.");
    if (!email.includes("@")) return alert("Digite um e-mail válido.");
    if (senha.length < 6) return alert("A senha deve ter no mínimo 6 caracteres.");
    if (senha !== confirmarSenha) return alert("As senhas não conferem.");
    if (especialidade.length < 3) return alert("Informe a especialidade.");
    if (areaAtuacao.length < 3) return alert("Informe a área de atuação.");
    if (registroProfissional.length < 3) return alert("Informe o registro profissional.");
    if (!terms) return alert("Você precisa aceitar os termos e condições.");

fetch("http://localhost:3001/profissionais", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    nome_profissional: nome,
    email_profissional: email,
    senha_profissional: senha,
    registro_profissional: registroProfissional,
    especialidade: especialidade, // se especialidade for string, o backend precisa aceitar também
    areaAtuacao: areaAtuacao // nome da chave conforme backend aceite
  })
})
 .then(res => res.json())
    .then(data => {
        alert(data.message || "Cadastro realizado com sucesso!");
        window.location.href = "login.html";
    })
    .catch(err => {
        console.error(err);
        alert("Erro ao cadastrar profissional. Tente novamente.");
    });

  });