document.addEventListener("DOMContentLoaded", () => {
  const chk = document.getElementById('checkbox');

  // ===== MODO ESCURO =====
  if (localStorage.getItem('modo') === 'dark') {
    document.body.classList.add('dark');
    if (chk) chk.checked = true;
  }

  if (chk) {
    chk.addEventListener('change', () => {
      document.body.classList.toggle('dark');
      localStorage.setItem('modo', document.body.classList.contains('dark') ? 'dark' : 'light');
    });
  }

  // ===== LOGIN NORMAL =====
  const formLogin = document.getElementById("form-login");
  if (formLogin) {
    formLogin.addEventListener("submit", function (e) {
      e.preventDefault();

      const email = document.getElementById("email").value.trim();
      const password = document.getElementById("password").value.trim();

      if (!email || !password) {
        alert("Preencha todos os campos.");
        return;
      }

      fetch("http://localhost:3001/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email, senha: password })
      })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            if (data.tipo === "usuario") {
              localStorage.setItem("usuario", JSON.stringify(data.usuario));

              if (!data.usuario.CPF || data.usuario.CPF.trim() === "") {
                alert("⚠️ Você ainda não completou seu cadastro. Preencha seu CPF.");
                window.location.href = "Perfil.html";
              } else {
                alert(`Bem-vindo, ${data.usuario.nome_usuario}!`);
                window.location.href = "pagina_principal.html";
              }
            } else if (data.tipo === "profissional") {
              localStorage.setItem("profissional", JSON.stringify(data.profissional));

              if (!data.profissional.sobre_mim || data.profissional.sobre_mim.trim() === "") {
                alert("⚠️ Complete seu cadastro.");
                window.location.href = "perfil-profissional.html";
              } else {
                alert(`Bem-vindo, Dr(a). ${data.profissional.nome_profissional}!`);
                window.location.href = "profissional-principal.html";
              }
            }
          } else {
            alert(data.message || "E-mail ou senha inválidos.");
          }
        })
        .catch(err => {
          console.error("Erro ao logar:", err);
          alert("Erro de conexão com o servidor.");
        });
    });
  }

  // ===== LOGIN COM GOOGLE =====
  window.handleCredentialResponse = async function (response) {
    try {
      const token = response.credential;

      // Decodifica o token JWT do Google
      const payload = JSON.parse(atob(token.split(".")[1]));

      const email = payload.email;
      const nome = payload.name;
      const foto = payload.picture;

      // Envia ao backend
      const res = await fetch("http://localhost:3001/auth/google", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token,
          email,
          nome,
          foto
        })
      });

      const data = await res.json();
      console.log("Resposta Google Login:", data);

      if (!data.success) {
        alert(data.message || "Erro no login com Google.");
        return;
      }

      // LOGIN COMO USUÁRIO
      if (data.tipo === "usuario") {
        localStorage.setItem("usuario", JSON.stringify(data.usuario));

        if (!data.usuario.CPF || data.usuario.CPF.trim() === "") {
          alert("⚠️ Complete seu cadastro (CPF).");
          window.location.href = "Perfil.html";
        } else {
          alert(`Bem-vindo, ${data.usuario.nome_usuario}!`);
          window.location.href = "pagina_principal.html";
        }
      }

      /*// LOGIN COMO PROFISSIONAL
      if (data.tipo === "profissional") {
        localStorage.setItem("profissional", JSON.stringify(data.profissional));

        if (!data.profissional.sobre_mim || data.profissional.sobre_mim.trim() === "") {
          alert("⚠️ Complete seu cadastro profissional.");
          window.location.href = "perfil-profissional.html";
        } else {
          alert(`Bem-vindo, Dr(a). ${data.profissional.nome_profissional}!`);
          window.location.href = "profissional-principal.html";
        }
      }*/

    } catch (error) {
      console.error("Erro no Google Login:", error);
      alert("Erro ao autenticar com Google.");
    }
  };

  // ===== ESQUECI SENHA =====
  const forgotPasswordLink = document.querySelector(".forgot-password a");
  if (forgotPasswordLink) {
    forgotPasswordLink.addEventListener("click", (e) => {
      e.preventDefault();
      window.location.href = "esqueci-senha.html";
    });
  }

});
