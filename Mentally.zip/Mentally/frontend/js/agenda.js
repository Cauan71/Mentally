document.addEventListener("DOMContentLoaded", () => {
  const agendaList = document.getElementById("agendaList");
  const modal = document.getElementById("modal");
  const closeModalBtn = document.getElementById("closeModal");
  const addAgendamentoBtn = document.getElementById("addAgendamentoBtn");
  const agendamentoForm = document.getElementById("agendamentoForm");

  // Inputs do Modal
  const inputPaciente = document.getElementById("nomePaciente");
  const inputData = document.getElementById("dataAgendamento");
  const inputHora = document.getElementById("horaAgendamento");

  // 1. Recupera o profissional logado do LocalStorage
  const profissionalLogado = JSON.parse(localStorage.getItem("profissional"));
  const idProfissional = profissionalLogado ? profissionalLogado.idProfissional : null;

  if (!idProfissional) {
    if (agendaList) {
      agendaList.innerHTML = `
        <div style="text-align:center; padding: 2rem; color: #ccc;">
          <i class="ri-error-warning-line" style="font-size: 2rem; display:block; margin-bottom:10px"></i>
          <p>Nenhum profissional identificado. Por favor, faça login novamente.</p>
        </div>`;
    }
    return;
  }

  // 2. Função para formatar Data (DD/MM/AAAA)
  function formatarData(dataISO) {
    if (!dataISO) return "-";
    const data = new Date(dataISO);
    return data.toLocaleDateString('pt-BR', { timeZone: 'UTC' }); 
    // timeZone UTC evita que a data volte 1 dia dependendo do fuso
  }

  // 3. Carregar Agendamentos (GET)
  async function carregarAgendamentos() {
    if (!agendaList) return;
    
    agendaList.innerHTML = `<p style="text-align:center;">Carregando...</p>`;

    try {
      const response = await fetch(`http://localhost:3001/agendamentos/profissional/${idProfissional}`);
      
      if (!response.ok) throw new Error("Erro na resposta da API");
      
      const agendamentos = await response.json();
      renderAgenda(agendamentos);
      
    } catch (error) {
      console.error("Erro ao buscar agendamentos:", error);
      agendaList.innerHTML = `<p style="text-align:center; color:#ff6b6b;">Erro ao carregar agenda.</p>`;
    }
  }

  // 4. Renderizar a Lista na Tela
  function renderAgenda(agendamentos) {
    agendaList.innerHTML = "";

    if (!agendamentos || agendamentos.length === 0) {
      agendaList.innerHTML = `
        <div style="text-align:center; padding: 2rem; opacity: 0.7;">
          <i class="ri-calendar-line" style="font-size: 3rem; margin-bottom: 10px; display:block;"></i>
          <p>Nenhum agendamento encontrado.</p>
        </div>`;
      return;
    }

    agendamentos.forEach(ag => {
      // Ajuste os nomes das propriedades conforme seu retorno do Banco de Dados
      const nomePaciente = ag.nome_usuario || ag.nome || "Paciente não identificado";
      const cpfPaciente = ag.cpf_usuario || "Não informado";
      const telefonePaciente = ag.telefone_usuario || ag.telefone || "-";
      const dataFormatada = formatarData(ag.data_consulta);
      const horaFormatada = ag.hora_consulta ? ag.hora_consulta.slice(0, 5) : "-"; // Corta os segundos se houver
      const observacao = ag.observacao_consulta || "Sem observações.";

      // Cria o elemento
      const card = document.createElement("div");
      card.className = "agendamento-card";

      card.innerHTML = `
        <div class="card-top">
          <h3><i class="ri-user-heart-line"></i> ${nomePaciente}</h3>
          <span class="badge-data"><i class="ri-calendar-event-line"></i> ${dataFormatada} às ${horaFormatada}</span>
        </div>

        <div class="card-body">
          <div class="info-group">
            <h4>Contato</h4>
            <p><i class="ri-phone-line"></i> ${telefonePaciente}</p>
            <p><i class="ri-mail-line"></i> ${ag.email_usuario || "-"}</p>
          </div>
          
          <div class="info-group">
            <h4>Observações</h4>
            <p>${observacao}</p>
          </div>
        </div>

        <div class="card-actions">
          <button class="btn-entrar" onclick="alert('Iniciando teleconsulta com ${nomePaciente}...')">
            <i class="ri-video-chat-line"></i> Entrar na Consulta
          </button>
        </div>
      `;

      agendaList.appendChild(card);
    });
  }

  // 5. Controles do Modal (Abrir/Fechar)
  if (addAgendamentoBtn) {
    addAgendamentoBtn.addEventListener("click", () => {
      modal.style.display = "flex";
    });
  }

  if (closeModalBtn) {
    closeModalBtn.addEventListener("click", () => {
      modal.style.display = "none";
    });
  }

  window.addEventListener("click", (e) => {
    if (e.target === modal) modal.style.display = "none";
  });

  // 6. Enviar Novo Agendamento (POST)
  if (agendamentoForm) {
    agendamentoForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const nome = inputPaciente.value;
      const data = inputData.value;
      const hora = inputHora.value;

      if (!nome || !data || !hora) {
        alert("Preencha todos os campos!");
        return;
      }

      // OBS: No backend real, você precisaria do ID do usuário, não do nome.
      // Aqui estou pegando de um localStorage hipotético ou enviando null.
      // Ajuste conforme sua lógica de seleção de paciente.
      const pacienteSelecionado = JSON.parse(localStorage.getItem("pacienteSelecionado")); 
      const idUsuario = pacienteSelecionado ? pacienteSelecionado.idUsuario : null; 

      const payload = {
        PROFISSIONAIS_idProfissional: idProfissional,
        USUARIO_idUsuario: idUsuario, // Se for null, seu backend precisa tratar
        nome_paciente_temp: nome,     // Caso seu backend aceite nome avulso
        data_consulta: data,
        hora_consulta: hora
      };

      try {
        const response = await fetch("http://localhost:3001/agendamentos", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });

        if (response.ok) {
          alert("Agendamento realizado com sucesso!");
          modal.style.display = "none";
          agendamentoForm.reset();
          carregarAgendamentos(); // Recarrega a lista
        } else {
          alert("Erro ao salvar agendamento.");
        }
      } catch (err) {
        console.error(err);
        alert("Erro de conexão com o servidor.");
      }
    });
  }

  // Inicializa a tela
  carregarAgendamentos();
});