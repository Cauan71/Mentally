/* ===================================================================
   0. CONFIGURAÇÃO BÁSICA
=================================================================== */
const API_URL = "http://localhost:3001";

function resolveAvatar(url) {
    if (!url) return "img/perfilsiru.jpg";
    if (url.startsWith("http://") || url.startsWith("https://")) return url;
    return API_URL + url;
}

/* ===================================================================
   1. MENU MOBILE
=================================================================== */
const btnMobile = document.getElementById('btn-mobile');
if (btnMobile) {
    const nav = document.getElementById('nav');
    const menu = document.getElementById('menu');
    const hamburger = document.getElementById('hamburger');
    const desktopSocial = document.getElementById('navigation_social');
    const desktopIcons = document.getElementById('icons');
    const desktopTitle = document.getElementById('title');

    function toggleMenu(event) {
        if (event.type === 'touchstart') event.preventDefault();
        nav.classList.toggle('active');
        hamburger.classList.toggle('active');
        const active = nav.classList.contains('active');
        event.currentTarget.setAttribute('aria-expanded', active);
        event.currentTarget.setAttribute('aria-label', active ? 'Fechar Menu' : 'Abrir Menu');

        if (active && window.innerWidth <= 1100) {
            if (desktopTitle && !document.getElementById('mobile-title')) {
                const mobileTitle = desktopTitle.cloneNode(true);
                mobileTitle.id = 'mobile-title';
                menu.prepend(mobileTitle);
            }
            if (desktopSocial && !document.getElementById('mobile-social')) {
                const mobileSocial = desktopSocial.cloneNode(true);
                mobileSocial.id = 'mobile-social';
                menu.appendChild(mobileSocial);
            }
            if (desktopIcons && !document.getElementById('mobile-icons')) {
                const mobileIcons = desktopIcons.cloneNode(true);
                mobileIcons.id = 'mobile-icons';
                menu.appendChild(mobileIcons);
            }
        }

        if (!active) {
            const mobileTitle = document.getElementById('mobile-title');
            const mobileSocial = document.getElementById('mobile-social');
            const mobileIcons = document.getElementById('mobile-icons');
            if (mobileTitle) mobileTitle.remove();
            if (mobileSocial) mobileSocial.remove();
            if (mobileIcons) mobileIcons.remove();
        }
    }

    btnMobile.addEventListener('click', toggleMenu);
    btnMobile.addEventListener('touchstart', toggleMenu);
}

/* ===================================================================
   2. DARK MODE / LIGHT MODE
=================================================================== */
const chk = document.getElementById("checkbox");
const logos = document.querySelectorAll(".logo");

function updateLogos(src) {
    logos.forEach(img => img.src = src);
}

if (localStorage.getItem("modo") === "dark") {
    document.body.classList.add("dark");
    if (chk) chk.checked = true;
    updateLogos("/img/mentaally colorido.png");
} else {
    updateLogos("/img/mentaally.png");
}

if (chk) {
    chk.addEventListener("change", () => {
        document.body.classList.toggle("dark");
        if (document.body.classList.contains("dark")) {
            localStorage.setItem("modo", "dark");
            updateLogos("/img/mentaally colorido.png");
        } else {
            localStorage.setItem("modo", "light");
            updateLogos("/img/mentaally.png");
        }
    });
}

/* ===================================================================
   3. PERFIL DO USUÁRIO
=================================================================== */
const form = document.getElementById("formPerfil");

if (form) {
    const nomeUsuario = document.getElementById("nome-usuario");
    const nomeCompleto = document.getElementById("nomeCompleto");
    const membroDesde = document.getElementById("membroDesde");
    const inputNome = document.getElementById("inputNome");
    const inputEmail = document.getElementById("inputEmail");
    const inputTelefone = document.getElementById("inputTelefone");
    const inputCPF = document.getElementById("inputCPF");
    const profileImage = document.getElementById("profileImage");
    const uploadInput = document.getElementById("uploadInput");
    const inputData = document.getElementById("dtNascimento");
    const inputPlano = document.getElementById("plano_tratamento");
    const modal = document.getElementById("modal");
    const modalImage = document.getElementById("modalImage");

    let user = JSON.parse(localStorage.getItem("usuario"));

    async function carregarPerfil() {
        if (!user) return;

        try {
            const response = await fetch(`${API_URL}/usuarios/${user.id_usuario}`);
            const dados = await response.json();
            user = dados;
            localStorage.setItem("usuario", JSON.stringify(dados));

            // Atualiza interface
            nomeUsuario.textContent = dados.nome_usuario || "";
            nomeCompleto.textContent = dados.nome_usuario || "";
            membroDesde.textContent = "Membro desde " + new Date(dados.criado_em).toLocaleDateString("pt-BR");
            inputNome.value = dados.nome_usuario || "";
            inputEmail.value = dados.email_usuario || "";
            inputTelefone.value = dados.telefone || "";
            inputCPF.value = dados.cpf || ""; // ✅ Corrigido
            inputData.value = dados.dtNascimento ? dados.dtNascimento.split("T")[0] : "";
            inputPlano.value = dados.plano_tratamento || "";
            profileImage.src = resolveAvatar(dados.avatar_url);

        } catch (err) {
            console.error("Erro ao carregar perfil:", err);
        }
    }

    carregarPerfil();

    /* ============================
       UPLOAD DE AVATAR
    ============================ */
    uploadInput.addEventListener("change", async () => {
        if (!uploadInput.files.length) return;
        const file = uploadInput.files[0];
        const formData = new FormData();
        formData.append("avatar", file);
        formData.append("id_usuario", user.id_usuario);

        try {
            const res = await fetch(`${API_URL}/usuarios/avatar`, {
                method: "POST",
                body: formData
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.message || "Erro ao enviar avatar");

            alert("Imagem enviada com sucesso!");
            profileImage.src = data.url;
            user.avatar_url = data.url;
            localStorage.setItem("usuario", JSON.stringify(user));

        } catch (err) {
            alert("Erro ao enviar avatar: " + err.message);
        }
    });

    /* ============================
       MODAL DE IMAGEM
    ============================ */
    if (modal && profileImage && modalImage) {
        profileImage.addEventListener("click", () => {
            modalImage.src = profileImage.src;
            modal.style.display = "flex";
        });
        modal.addEventListener("click", () => {
            modal.style.display = "none";
        });
    }

    /* ============================
       SALVAR PERFIL
    ============================ */
    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        // Validação CPF
        if (inputCPF.value && !inputCPF.value.match(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/)) {
            alert("CPF inválido. Use o formato 000.000.000-00");
            return;
        }

        const dadosAtualizados = {
            nome_usuario: inputNome.value,
            email_usuario: inputEmail.value,
            telefone: inputTelefone.value,
            cpf: inputCPF.value, // ✅ Corrigido
            dtNascimento: inputData.value,
            plano_tratamento: inputPlano.value
        };

        try {
            const response = await fetch(`${API_URL}/usuarios/${user.id_usuario}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(dadosAtualizados),
            });

            if (!response.ok) {
                const erro = await response.json();
                throw new Error(erro.error || erro.message || "Erro ao atualizar perfil");
            }

            const dadosServidor = await response.json();
            alert("✅ Perfil atualizado com sucesso!");
            user = dadosServidor;
            localStorage.setItem("usuario", JSON.stringify(dadosServidor));

            // Atualiza interface
            nomeUsuario.textContent = dadosServidor.nome_usuario;
            nomeCompleto.textContent = dadosServidor.nome_usuario;
            inputNome.value = dadosServidor.nome_usuario;
            inputEmail.value = dadosServidor.email_usuario;
            inputTelefone.value = dadosServidor.telefone || "";
            inputCPF.value = dadosServidor.cpf || ""; // ✅ Corrigido
            inputData.value = dadosServidor.dtNascimento ? dadosServidor.dtNascimento.split("T")[0] : "";
            inputPlano.value = dadosServidor.plano_tratamento || "";
            profileImage.src = resolveAvatar(dadosServidor.avatar_url);

        } catch (err) {
            alert(err.message);
        }
    });

    /* ============================
       EXCLUIR CONTA
    ============================ */
    window.excluirConta = async () => {
        if (!user) return;
        if (confirm("Tem certeza? Essa ação é irreversível.")) {
            try {
                const res = await fetch(`${API_URL}/usuarios/${user.id_usuario}`, { method: "DELETE" });
                if (!res.ok) {
                    const data = await res.json();
                    throw new Error(data.message || "Erro ao excluir conta");
                }
                alert("Conta excluída!");
                localStorage.removeItem("usuario");
                window.location.href = "index.html";
            } catch (err) {
                alert("Erro ao excluir conta: " + err.message);
            }
        }
    };
}

/* ===================================================================
   4. ABAS
=================================================================== */
const tabButtons = document.querySelectorAll(".tab-btn");
const tabContents = document.querySelectorAll(".tab-content");

tabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
        tabButtons.forEach(b => b.classList.remove("active"));
        tabContents.forEach(c => c.classList.remove("active"));

        btn.classList.add("active");
        const targetTab = document.getElementById(btn.dataset.tab);
        if (targetTab) targetTab.classList.add("active");
    });
});
