const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const path = require("path");
const multer = require("multer");
const crypto = require("crypto");// para gerar senha aleatória
const bcrypt = require("bcrypt"); // para hashear a senha
const router = express.Router();

const app = express();
app.use(cors({
  origin: "http://localhost:3001",
  credentials: true
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));


// SERVIR FRONTEND
const frontendPath = path.join(__dirname, "../frontend");
app.use(express.static(frontendPath));

// SERVIR ARQUIVOS DE IMAGEM (uploads)
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Adicionalmente, para garantir que /img funcione:
app.use('/img', express.static(path.join(frontendPath, 'img')));
// CONFIGURAÇÃO DO MULTER (UPLOAD DE AVATAR)
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, "uploads")),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, Date.now() + ext);
  }
});
const upload = multer({ storage });


// CONEXÃO COM MYSQL
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password:"",
  database: "MENTALLY"
});

db.connect(err => {
  if (err) return console.error("❌ Erro ao conectar MySQL:", err);
  console.log("✅ Conectado ao MySQL");
});

const nodemailer = require("nodemailer");
// CONFIGURAÇÃO DO SERVIDOR DE E-MAIL
const transporter = nodemailer.createTransport({
  service: "gmail", // pode alterar para "hotmail", "outlook", "smtp" etc
  auth: {
    user: "joaoluiza6@gmail.com",
    pass: "zxhw hmyo czxh vrlb", // NÃO é a senha normal – é a senha de app
  },
});

// ======================= ROTAS ============================
app.get("/Perfil.html", (req, res) => {
  res.sendFile(path.join(frontendPath, "Perfil.html"));
});


// 🔍 Obter todos usuários
app.get("/usuarios", (req, res) => {
  db.query(
    "SELECT id_usuario, CPF, nome_usuario, email_usuario, telefone, plano_tratamento, criado_em, avatar FROM USUARIO",
    (err, results) => {
      if (err) return res.status(500).json(err);
      res.json(results);
    }
  );
});

// ✅ Cadastro de novo usuário
app.post("/usuarios", (req, res) => {
  const { nome_usuario, email_usuario, senha_usuario } = req.body;
  if (!nome_usuario || !email_usuario || !senha_usuario)
    return res.status(400).json({ message: "Preencha todos os campos." });

  const sql = "INSERT INTO USUARIO (nome_usuario, email_usuario, senha_usuario) VALUES (?, ?, SHA2(?,256))";
  db.query(sql, [nome_usuario, email_usuario, senha_usuario], (err) => {
    if (err) return res.status(500).json({ message: "Erro ao cadastrar usuário." });
    res.json({ message: "Usuário cadastrado com sucesso!" });
  });
});

// ✅ cadastro de novo profissional
app.post("/profissionais", async (req, res) => {
  const {
    nome_profissional,
    email_profissional,
    senha_profissional,
    registro_profissional,
    especialidade,
    areaAtuacao
  } = req.body;

  try {
    // 1. Garantir que Especialidade existe
    let [espRows] = await db
      .promise()
      .query("SELECT especialidade_PK FROM ESPECIALIDADE WHERE especialidade = ?", [especialidade]);

    let especialidadeId;
    if (espRows.length > 0) {
      especialidadeId = espRows[0].especialidade_PK;
    } else {
      let [insertEsp] = await db
        .promise()
        .query("INSERT INTO ESPECIALIDADE (especialidade) VALUES (?)", [especialidade]);
      especialidadeId = insertEsp.insertId;
    }

    // 2. Garantir que Área de Atuação existe
    let [areaRows] = await db
      .promise()
      .query("SELECT areaAtuacao_PK FROM AREA_ATUACAO WHERE areaAtuacao = ?", [areaAtuacao]);

    let areaId;
    if (areaRows.length > 0) {
      areaId = areaRows[0].areaAtuacao_PK;
    } else {
      let [insertArea] = await db
        .promise()
        .query("INSERT INTO AREA_ATUACAO (areaAtuacao) VALUES (?)", [areaAtuacao]);
      areaId = insertArea.insertId;
    }

    // 3. Inserir Profissional com os IDs corretos e senha criptografada
    await db
      .promise()
      .query(
        `INSERT INTO PROFISSIONAIS 
        (AREA_ATUACAO_areaAtuacao_PK, ESPECIALIDADE_especialidade_PK, nome_profissional, senha_profissional, email_profissional, registro_profissional) 
        VALUES (?, ?, ?, SHA2(?,256), ?, ?)`,
        [areaId, especialidadeId, nome_profissional, senha_profissional, email_profissional, registro_profissional]
      );

    res.json({ message: "Profissional cadastrado com sucesso!" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao cadastrar profissional" });
  }
});




// 🔐 Login (usuário ou profissional)
app.post("/login", (req, res) => {
  const { email, senha } = req.body;

  if (!email || !senha) {
    return res.status(400).json({ success: false, message: "Preencha e-mail e senha." });
  }

  // 1️⃣ Tenta login como USUÁRIO
  const sqlUsuario = "SELECT * FROM USUARIO WHERE email_usuario = ? AND senha_usuario = SHA2(?,256)";
  db.query(sqlUsuario, [email, senha], (err, results) => {
    if (err) {
      console.error("Erro login usuário:", err);
      return res.status(500).json({ success: false, message: "Erro interno no servidor." });
    }

    if (results.length > 0) {
      return res.json({
        success: true,
        tipo: "usuario",
        usuario: results[0]
      });
    }

    // 2️⃣ Se não achou, tenta login como PROFISSIONAL
    const sqlProfissional = "SELECT * FROM PROFISSIONAIS WHERE email_profissional = ? AND senha_profissional = SHA2(?,256)";
    db.query(sqlProfissional, [email, senha], (err2, results2) => {
      if (err2) {
        console.error("Erro login profissional:", err2);
        return res.status(500).json({ success: false, message: "Erro interno no servidor." });
      }

      if (results2.length > 0) {
        return res.json({
          success: true,
          tipo: "profissional",
          profissional: results2[0]
        });
      }

      // 3️⃣ Nenhum encontrado
      return res.status(401).json({ success: false, message: "E-mail ou senha inválidos." });
    });
  });
});


// ===============================
// 🔐 ESQUECI A SENHA
// ===============================

// Função para enviar o e-mail de redefinição
function enviarEmailRedefinicao(email, token, res) {
  const resetUrl = `http://localhost:3001/redefinir-senha.html?token=${token}`;

  const mailOptions = {
    from: "MENTALLY <joaoluiza6@gmail.com>",
    to: email,
    subject: "Redefinição de senha",
    html: `
      <h2>Redefinição de Senha</h2>
      <p>Você pediu para redefinir sua senha.</p>
      <p>Clique no link abaixo para criar uma nova senha:</p>
      <a href="${resetUrl}" target="_blank">${resetUrl}</a>
      <br><br>
      <p>Se você não pediu isso, ignore este e-mail.</p>
      <p>O link expira em 1 hora.</p>
    `
  };

  transporter.sendMail(mailOptions, (erro) => {
    if (erro) {
      console.error("Erro ao enviar e-mail:", erro);
      return res.status(500).json({ success: false, message: "Erro ao enviar e-mail." });
    }
    res.json({ success: true, message: "E-mail enviado com sucesso!" });
  });
}

// 📌 FAZER SOLICITAÇÃO DE "ESQUECI A SENHA"
app.post("/esqueci-senha", (req, res) => {
  const { email } = req.body;

  if (!email)
    return res.status(400).json({ success: false, message: "E-mail é obrigatório." });

  const token = crypto.randomBytes(20).toString("hex");
  const expira = new Date(Date.now() + 3600000); // 1h

  // 1️⃣ Verificar email em USUARIO
  db.query(
    "SELECT id_usuario FROM USUARIO WHERE email_usuario = ?",
    [email],
    (err, resultsUsuario) => {
      if (err) return res.status(500).json({ success: false, message: "Erro interno." });

      if (resultsUsuario.length > 0) {
        return db.query(
          "UPDATE USUARIO SET reset_token = ?, reset_token_expira = ? WHERE id_usuario = ?",
          [token, expira, resultsUsuario[0].id_usuario],
          (err2) => {
            if (err2)
              return res.status(500).json({ success: false, message: "Erro ao salvar token." });

            enviarEmailRedefinicao(email, token, res);
          }
        );
      }

      // 2️⃣ Se não achou em USUARIO, verifica PROFISSIONAL
      db.query(
        "SELECT idProfissional FROM PROFISSIONAIS WHERE email_profissional = ?",
        [email],
        (err3, resultsProf) => {
          if (err3)
            return res.status(500).json({ success: false, message: "Erro interno." });

          if (resultsProf.length > 0) {
            return db.query(
              "UPDATE PROFISSIONAIS SET reset_token = ?, reset_token_expira = ? WHERE idProfissional = ?",
              [token, expira, resultsProf[0].idProfissional],
              (err4) => {
                if (err4)
                  return res.status(500).json({ success: false, message: "Erro ao salvar token." });

                enviarEmailRedefinicao(email, token, res);
              }
            );
          }

          res.status(404).json({ success: false, message: "E-mail não encontrado." });
        }
      );
    }
  );
});

// ===============================
// 🔎 VALIDAR TOKEN
// ===============================

app.get("/validar-token/:token", (req, res) => {
  const { token } = req.params;
  const agora = new Date();

  db.query(
    "SELECT id_usuario FROM USUARIO WHERE reset_token = ? AND reset_token_expira > ?",
    [token, agora],
    (err, results) => {
      if (err) return res.status(500).json({ success: false });

      if (results.length > 0) {
        return res.json({
          success: true,
          tipo: "usuario",
          id: results[0].id_usuario
        });
      }

      db.query(
        "SELECT idProfissional FROM PROFISSIONAIS WHERE reset_token = ? AND reset_token_expira > ?",
        [token, agora],
        (err2, results2) => {
          if (err2) return res.status(500).json({ success: false });

          if (results2.length > 0) {
            return res.json({
              success: true,
              tipo: "profissional",
              id: results2[0].idProfissional
            });
          }

          res.json({ success: false, message: "Token inválido ou expirado." });
        }
      );
    }
  );
});


// Login Google
const { OAuth2Client } = require("google-auth-library");
const googleClient = new OAuth2Client(
  "1056946571922-d1rkh34783qkv50bjmu3odjkmalqn9gf.apps.googleusercontent.com"
);


app.post("/auth/google", async (req, res) => {
  const { token } = req.body;

  try {
    // Validar token com Google
    const ticket = await googleClient.verifyIdToken({
      idToken: token,
      audience:
        "1056946571922-d1rkh34783qkv50bjmu3odjkmalqn9gf.apps.googleusercontent.com",
    });

    const payload = ticket.getPayload();
    const email = payload.email;
    const nome = payload.name;
    const avatar = payload.picture;
    const googleId = payload.sub; // ID único do Google

    // Verificar se já existe na tabela USUARIO
    db.query(
      "SELECT * FROM USUARIO WHERE email_usuario = ?",
      [email],
      (err, results) => {
        if (err) {
          console.error("Erro SELECT Google:", err);
          return res.status(500).json({ error: "Erro interno no servidor." });
        }

        if (results.length > 0) {
          // Usuário já existe → login direto
          const user = results[0];
          return res.json({
            success: true,
            tipo: "usuario",
            usuario: {
              id_usuario: user.id_usuario,
              nome_usuario: user.nome_usuario,
              email_usuario: user.email_usuario,
              CPF: user.CPF || null, // garante que front sempre tenha CPF
              google_id: user.google_id || null,
              google_name: user.google_name || null,
              google_avatar: user.google_avatar || null,
              avatar_url: user.avatar || user.google_avatar || null, // sempre envia avatar correto
            },
          });
        }

        // Senão, criar usuário automaticamente
        const senhaAleatoria = crypto.randomBytes(8).toString("hex"); // 16 caracteres
        const senhaHash = bcrypt.hashSync(senhaAleatoria, 10); // hash seguro

        const sql = `
          INSERT INTO USUARIO 
          (nome_usuario, email_usuario, senha_usuario, google_id, google_name, google_avatar, avatar) 
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `;

        db.query(
          sql,
          [nome, email, senhaHash, googleId, nome, avatar, avatar],
          (err2, result2) => {
            if (err2) {
              console.error("Erro INSERT Google:", err2);
              return res.status(500).json({ error: "Erro ao criar usuário." });
            }

            return res.json({
              success: true,
              tipo: "usuario",
              usuario: {
                id_usuario: result2.insertId,
                nome_usuario: nome,
                email_usuario: email,
                CPF: null, // CPF ainda não existe
                google_id: googleId,
                google_name: nome,
                google_avatar: avatar,
                avatar_url: avatar, // front sempre terá a imagem
              },
            });
          }
        );
      }
    );
  } catch (error) {
    console.error("Erro na autenticação Google:", error);
    return res.status(400).json({ error: "Token inválido." });
  }
});

// ===============================
// 🔐 REDEFINIR SENHA
// ===============================

app.post("/redefinir-senha", (req, res) => {
  const { token, novaSenha } = req.body;

  if (!token || !novaSenha)
    return res.status(400).json({ success: false, message: "Token e senha obrigatórios." });

  const agora = new Date();

  // 1️⃣ Usuário
  db.query(
    "SELECT id_usuario FROM USUARIO WHERE reset_token = ? AND reset_token_expira > ?",
    [token, agora],
    (err, resultsUser) => {
      if (err) return res.status(500).json({ success: false, message: "Erro interno." });

      if (resultsUser.length > 0) {
        const id = resultsUser[0].id_usuario;

        return db.query(
          "UPDATE USUARIO SET senha_usuario = SHA2(?,256), reset_token = NULL, reset_token_expira = NULL WHERE id_usuario = ?",
          [novaSenha, id],
          () => res.json({
            success: true,
            message: "Senha atualizada com sucesso!"
          })
        );
      }

      // 2️⃣ Profissional
      db.query(
        "SELECT idProfissional FROM PROFISSIONAIS WHERE reset_token = ? AND reset_token_expira > ?",
        [token, agora],
        (err2, resultsProf) => {
          if (err2) return res.status(500).json({ success: false, message: "Erro interno." });

          if (resultsProf.length > 0) {
            const id = resultsProf[0].idProfissional;

            return db.query(
              "UPDATE PROFISSIONAIS SET senha_profissional = SHA2(?,256), reset_token = NULL, reset_token_expira = NULL WHERE idProfissional = ?",
              [novaSenha, id],
              () => res.json({
                success: true,
                message: "Senha atualizada com sucesso!"
              })
            );
          }

          res.status(400).json({ success: false, message: "Token inválido ou expirado." });
        }
      );
    }
  );
});


// 🔄 Atualizar perfil do usuário
app.put("/usuarios/:id_usuario", (req, res) => {
    const { id_usuario } = req.params;
    const campos = [];
    const valores = [];

    // Percorre todos os campos enviados no body
    for (const [key, value] of Object.entries(req.body)) {
        campos.push(`${key} = ?`);
        valores.push(value);
    }

    if (campos.length === 0) {
        return res.status(400).json({ error: "Nenhum campo para atualizar" });
    }

    valores.push(id_usuario);
    const sql = `UPDATE USUARIO SET ${campos.join(", ")} WHERE id_usuario = ?`;

    db.query(sql, valores, (err) => {
        if (err) {
            console.error("Erro ao atualizar perfil:", err);
            return res.status(500).json({ error: "Erro ao atualizar perfil" });
        }

        // Busca o usuário atualizado para enviar de volta ao front
        const sqlGet = `SELECT * FROM USUARIO WHERE id_usuario = ?`;
        db.query(sqlGet, [id_usuario], (err2, resultados) => {
            if (err2) {
                console.error("Erro ao buscar usuário atualizado:", err2);
                return res.status(500).json({ error: "Erro ao buscar usuário atualizado" });
            }

            if (resultados.length === 0) {
                return res.status(404).json({ error: "Usuário não encontrado" });
            }

            const usuarioAtualizado = resultados[0];

            // Mapear campos para o front
            usuarioAtualizado.cpf = usuarioAtualizado.CPF || null;             // CPF do banco → cpf
            usuarioAtualizado.avatar_url = usuarioAtualizado.avatar || null;   // avatar do banco → avatar_url

            // Remover campos originais se quiser limpar
            delete usuarioAtualizado.CPF;
            delete usuarioAtualizado.avatar;

            res.json(usuarioAtualizado);
        });
    });
});



// ✏️ Atualizar perfil do profissional
app.put("/profissionais/:idProfissional", async (req, res) => {
  const { idProfissional } = req.params;
  const {
    nome_profissional,
    sobre_mim,
    ESPECIALIDADE_especialidade_PK,
    AREA_ATUACAO_areaAtuacao_PK,
    novaEspecialidade,
    novaAreaAtuacao
  } = req.body;

  try {
    let especialidadeId = ESPECIALIDADE_especialidade_PK;
    let areaId = AREA_ATUACAO_areaAtuacao_PK;

    // Criar nova especialidade, se houver
    if (novaEspecialidade) {
      const [insertEsp] = await db.promise().query(
        "INSERT INTO ESPECIALIDADE (especialidade) VALUES (?)",
        [novaEspecialidade]
      );
      especialidadeId = insertEsp.insertId;
    }

    // Criar nova área de atuação, se houver
    if (novaAreaAtuacao) {
      const [insertArea] = await db.promise().query(
        "INSERT INTO AREA_ATUACAO (areaAtuacao) VALUES (?)",
        [novaAreaAtuacao]
      );
      areaId = insertArea.insertId;
    }

    // Montar query dinamicamente para atualizar apenas os campos que vieram
    const campos = [];
    const valores = [];

    if (nome_profissional !== undefined) {
      campos.push("nome_profissional = ?");
      valores.push(nome_profissional);
    }
    if (sobre_mim !== undefined) {
      campos.push("sobre_mim = ?");
      valores.push(sobre_mim);
    }
    if (especialidadeId !== undefined) {
      campos.push("ESPECIALIDADE_especialidade_PK = ?");
      valores.push(especialidadeId);
    }
    if (areaId !== undefined) {
      campos.push("AREA_ATUACAO_areaAtuacao_PK = ?");
      valores.push(areaId);
    }

    if (campos.length === 0) {
      return res.status(400).json({ message: "Nenhum campo enviado para atualização." });
    }

    valores.push(idProfissional);

    await db.promise().query(
      `UPDATE PROFISSIONAIS SET ${campos.join(", ")} WHERE idProfissional = ?`,
      valores
    );

    const [updated] = await db.promise().query(
      "SELECT * FROM PROFISSIONAIS WHERE idProfissional = ?",
      [idProfissional]
    );

    res.json({ message: "✅ Perfil atualizado com sucesso!", profissional: updated[0] });
  } catch (err) {
    console.error("Erro ao atualizar profissional:", err);
    res.status(500).json({ error: "Erro ao atualizar perfil do profissional." });
  }
});


app.get('/usuarios/:id_usuario', (req, res) => {
  const { id_usuario } = req.params;

  const sql = `
  SELECT 
    id_usuario, 
    CPF AS cpf, 
    nome_usuario, 
    email_usuario, 
    telefone, 
    DATE_FORMAT(dtNascimento, '%Y-%m-%d') AS dtNascimento, 
    plano_tratamento, 
    criado_em AS criado_em, 
    avatar AS avatar_url 
    FROM USUARIO 
    WHERE id_usuario = ?`;

  db.query(sql, [id_usuario], (err, results) => {
    if (err) {
      console.error('Erro ao buscar usuário:', err);
      return res.status(500).json({ error: 'Erro ao buscar usuário' });
    }

    if (results.length === 0) {
      return res.status(404).json({ error: 'Usuário não encontrado' });
    }

    res.json(results[0]);
  });
});

// 🖼️ Upload de avatar
// Upload de avatar para usuários
app.post("/usuarios/avatar", upload.single("avatar"), (req, res) => {
   console.log(req.file);
  const { id_usuario } = req.body;

  if (!req.file || !id_usuario) {
    return res.status(400).json({ message: "Arquivo ou ID do usuário ausente." });
  }

  const avatarUrl = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;
  const sql = "UPDATE USUARIO SET avatar = ? WHERE id_usuario = ?";

  db.query(sql, [avatarUrl, id_usuario], (err) => {
    if (err) return res.status(500).json({ message: "Erro ao salvar avatar." });

    res.json({ message: "Avatar atualizado com sucesso!", url: avatarUrl });
  });
});

// Upload de avatar para profissionais
app.post("/profissionais/avatar", upload.single("avatar"), (req, res) => {
   console.log(req.file);
  const { id_profissional } = req.body;

  if (!req.file || !id_profissional) {
    return res.status(400).json({ message: "Arquivo ou ID do profissional ausente." });
  }

  const avatarUrl = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;
  const sql = "UPDATE PROFISSIONAIS SET avatar = ? WHERE idProfissional = ?";

  db.query(sql, [avatarUrl, id_profissional], (err) => {
    if (err) return res.status(500).json({ message: "Erro ao salvar avatar." });

    res.json({ message: "Avatar atualizado com sucesso!", url: avatarUrl });
  });
});

// 📅 Agendamento
app.post("/agendamentos", (req, res) => {
  console.log("📥 Dados recebidos para agendamento:", req.body);
  const {
    PROFISSIONAIS_idProfissional,
    USUARIO_idUsuario,
    data_consulta,
    hora_consulta,
    relato_consulta,
    nota_consulta,
    observacao_consulta
  } = req.body;

  if (!PROFISSIONAIS_idProfissional || !USUARIO_idUsuario || !data_consulta || !hora_consulta) {
    return res.status(400).json({ message: 'Campos obrigatórios ausentes.' });
  }

  const sql = `
    INSERT INTO CONSULTA (
      PROFISSIONAIS_idProfissional,
      USUARIO_idUsuario,
      data_consulta,
      hora_consulta,
      relato_consulta,
      nota_consulta,
      observacao_consulta
    ) VALUES (?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(sql, [
    PROFISSIONAIS_idProfissional,
    USUARIO_idUsuario, // ✅ corrigido
    data_consulta,
    hora_consulta,
    relato_consulta,
    nota_consulta,
    observacao_consulta
  ], (err, result) => {
    if (err) {
      console.error("Erro ao agendar:", err);
      return res.status(500).json({ message: "Erro ao agendar." });
    }
    res.json({ message: "✅ Agendamento realizado com sucesso!" });
  });
});

// 🔍 Listar agendamentos de um usuário
app.get("/agendamentos/:idUsuario", (req, res) => {
  const { idUsuario } = req.params;

  const sql = `
    SELECT 
      c.idCONSULTA AS id_consulta,
      c.data_consulta,
      c.hora_consulta,
      c.observacao_consulta,
      p.nome_profissional,
      p.avatar AS foto_profissional,  -- ADICIONADO
      e.especialidade,
      a.areaAtuacao
    FROM CONSULTA c
    JOIN PROFISSIONAIS p ON c.PROFISSIONAIS_idProfissional = p.idProfissional
    JOIN ESPECIALIDADE e ON p.ESPECIALIDADE_especialidade_PK = e.especialidade_PK
    JOIN AREA_ATUACAO a ON p.AREA_ATUACAO_areaAtuacao_PK = a.areaAtuacao_PK
    WHERE c.USUARIO_idUsuario = ?
    ORDER BY c.data_consulta ASC, c.hora_consulta ASC
  `;

  db.query(sql, [idUsuario], (err, results) => {
    if (err) {
      console.error("Erro ao buscar agendamentos:", err);
      return res.status(500).json({ message: "Erro ao buscar agendamentos." });
    }
    res.json(results);
  });
});



// Obter profissional pelo ID
app.get("/profissionais/:idProfissional", async (req, res) => {
  const { idProfissional } = req.params;

  try {
    const [results] = await db.promise().query(`
      SELECT 
        p.idProfissional,
        p.nome_profissional,
        p.email_profissional,
        p.registro_profissional,
        p.sobre_mim,
        p.membroDesde,
        p.avatar AS avatar_url,
        e.especialidade,
        a.areaAtuacao
      FROM PROFISSIONAIS p
      LEFT JOIN ESPECIALIDADE e ON p.ESPECIALIDADE_especialidade_PK = e.especialidade_PK
      LEFT JOIN AREA_ATUACAO a ON p.AREA_ATUACAO_areaAtuacao_PK = a.areaAtuacao_PK
      WHERE p.idProfissional = ?
    `, [idProfissional]);

    if (results.length === 0) 
      return res.status(404).json({ error: "Profissional não encontrado" });

    res.json(results[0]);
  } catch (err) {
    console.error("Erro ao buscar profissional:", err);
    res.status(500).json({ error: "Erro ao buscar profissional" });
  }
});

// 🔍 Listar todos os profissionais
app.get("/profissionais", (req, res) => {
  const sql = `
    SELECT 
      p.idProfissional,
      p.nome_profissional,
      p.email_profissional,
      p.registro_profissional,
      p.sobre_mim,
      p.membroDesde,
      p.avatar AS avatar_url,
      e.especialidade,
      a.areaAtuacao
    FROM PROFISSIONAIS p
    LEFT JOIN ESPECIALIDADE e ON p.ESPECIALIDADE_especialidade_PK = e.especialidade_PK
    LEFT JOIN AREA_ATUACAO a ON p.AREA_ATUACAO_areaAtuacao_PK = a.areaAtuacao_PK
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Erro ao buscar profissionais:", err);
      return res.status(500).json({ error: "Erro ao buscar profissionais" });
    }
    res.json(results);
  });
});

// Backend: buscar pacientes de um profissional específico
app.get("/pacientes/:idProfissional", (req, res) => {
  const { idProfissional } = req.params;

  const query = `
    SELECT 
      u.id_usuario AS idUsuario, 
      u.nome_usuario AS nome, 
      u.email_usuario AS email, 
      u.telefone, 
      u.dtNascimento AS data_nascimento,
      u.avatar -- ADICIONADO
    FROM USUARIO u
    JOIN CONSULTA c ON u.id_usuario = c.USUARIO_idUsuario
    WHERE c.PROFISSIONAIS_idProfissional = ?
    GROUP BY u.id_usuario
  `;

  db.query(query, [idProfissional], (err, results) => {
    if (err) {
      console.error("Erro ao buscar pacientes:", err);
      return res.status(500).json({ error: err.message });
    }

    // Ajustar o campo avatar para frontend
    const pacientes = results.map(p => ({
      ...p,
      avatar_url: p.avatar || null // ESSENCIAL para o frontend mostrar a foto
    }));

    res.json(pacientes);
  });
});


// 📅 Listar agendamentos de um profissional com dados do paciente
app.get("/agendamentos/profissional/:idProfissional", (req, res) => {
  const { idProfissional } = req.params;

  const query = `
    SELECT 
      c.idCONSULTA AS id_consulta,
      c.data_consulta,
      c.hora_consulta,
      c.observacao_consulta,
      u.id_usuario AS idUsuario,
      u.nome_usuario AS nome_usuario,
      u.cpf AS cpf_usuario,
      u.email_usuario AS email_usuario,
      u.telefone AS telefone_usuario
    FROM CONSULTA c
    JOIN USUARIO u ON u.id_usuario = c.USUARIO_idUsuario
    WHERE c.PROFISSIONAIS_idProfissional = ?
    ORDER BY c.data_consulta ASC, c.hora_consulta ASC
  `;

  db.query(query, [idProfissional], (err, results) => {
    if (err) {
      console.error("Erro ao buscar agendamentos:", err);
      return res.status(500).json({ error: "Erro ao buscar agendamentos." });
    }
    res.json(results);
  });
});


// Rota para carregar todas as especialidades
app.get("/especialidades", (req, res) => {
  db.query("SELECT especialidade_PK, especialidade FROM ESPECIALIDADE", (err, results) => {
    if (err) {
      console.error("Erro ao buscar especialidades:", err);
      return res.status(500).json({ message: "Erro ao carregar especialidades." });
    }
    res.json(results);
  });
});

// Rota para carregar todas as áreas de atuação
app.get("/areasAtuacao", (req, res) => {
  db.query("SELECT areaAtuacao_PK, areaAtuacao FROM AREA_ATUACAO", (err, results) => {
    if (err) {
      console.error("Erro ao buscar áreas de atuação:", err);
      return res.status(500).json({ message: "Erro ao carregar áreas de atuação." });
    }
    res.json(results);
  });
});

// Buscar especialidade pelo ID
app.get("/especialidades/:id", (req, res) => {
  const id = req.params.id;
  db.query("SELECT especialidade FROM ESPECIALIDADE WHERE especialidade_PK = ?", [id], (err, results) => {
    if (err) {
      console.error("Erro ao buscar especialidade:", err);
      return res.status(500).json({ message: "Erro ao carregar especialidade." });
    }
    if (results.length === 0) {
      return res.status(404).json({ message: "Especialidade não encontrada." });
    }
    res.json(results[0]);
  });
});

// Buscar área de atuação pelo ID
app.get("/areasAtuacao/:id", (req, res) => {
  const id = req.params.id;
  db.query("SELECT areaAtuacao FROM AREA_ATUACAO WHERE areaAtuacao_PK = ?", [id], (err, results) => {
    if (err) {
      console.error("Erro ao buscar área de atuação:", err);
      return res.status(500).json({ message: "Erro ao carregar área de atuação." });
    }
    if (results.length === 0) {
      return res.status(404).json({ message: "Área de atuação não encontrada." });
    }
    res.json(results[0]);
  });
});



// 🗑️ Excluir usuário
app.delete("/usuarios/:id_usuario", (req, res) => {
  const { id_usuario } = req.params;

  const sql = "DELETE FROM USUARIO WHERE id_usuario = ?";

  db.query(sql, [id_usuario], (err, result) => {
    if (err) {
      console.error("Erro ao excluir usuário:", err);
      return res.status(500).json({ message: "Erro ao excluir usuário." });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Usuário não encontrado." });
    }

    res.json({ message: "Conta excluída com sucesso!" });
  });
});

// 🗑️ Cancelar / Excluir consulta
app.delete("/agendamentos/:id_consulta", (req, res) => {
  const { id_consulta } = req.params;

  const sql = "DELETE FROM CONSULTA WHERE idCONSULTA = ?";
  db.query(sql, [id_consulta], (err, result) => {
    if (err) {
      console.error("Erro ao cancelar consulta:", err);
      return res.status(500).json({ message: "Erro ao cancelar consulta." });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Consulta não encontrada." });
    }

    res.json({ message: "✅ Consulta cancelada com sucesso!" });
  });
});

// 🗑️ Excluir profissional
app.delete("/profissionais/:idProfissional", (req, res) => {
  const { idProfissional } = req.params;

  const sql = "DELETE FROM PROFISSIONAIS WHERE idProfissional = ?";

  db.query(sql, [idProfissional], (err, result) => {
    if (err) {
      console.error("Erro ao excluir profissional:", err);
      return res.status(500).json({ message: "Erro ao excluir profissional." });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Profissional não encontrado." });
    }

    res.json({ message: "✅ Profissional excluído com sucesso!" });
  });
});


// SPA fallback
app.get("/", (req, res) => {
  res.sendFile(path.join(frontendPath, "index.html"));
});


// Iniciar servidor
const PORT = 3001;
app.listen(PORT, () => console.log(`🚀 Servidor rodando em http://localhost:${PORT}`));



